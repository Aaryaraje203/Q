﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GymApplication.Models;

namespace GymApplication.Controllers
{
    public class GymController : Controller
    {
        Training_18Jan2017_TalwadeEntities1 context = new Training_18Jan2017_TalwadeEntities1();
        //
        // GET: /Gym/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DisplayAllData()
        {
            var displayAllData = from table in context.GymManagementSystems
                        select table;
            ViewBag.gymdata = displayAllData;
            return View();
        }

        public ActionResult AddRecord()
        {
            return View();
        }

        [HttpPost]
        public ActionResult AddRecord(GymManagementSystem gym)
        {
            
            if (ModelState.IsValid)
            {
                context.GymManagementSystems.Add(gym);
                context.SaveChanges();
                return RedirectToAction("DisplayAllData");
            }
            else
            {
                return View(gym);
            }
        }

        public ActionResult ViewMembers()
        {
            return View(context.GymManagementSystems);
        }
        [HttpGet]
        public ActionResult Details(int id)
        {
            var query = from a in context.GymManagementSystems
                        where a.MemberID == id
                        select a;

            return View(query.First());
        }

        public ActionResult Delete()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            if (ModelState.IsValid)
            {
                GymManagementSystem objgym = new GymManagementSystem();
                objgym = context.GymManagementSystems.Find(id);
                context.GymManagementSystems.Remove(objgym);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }

        }

        public ActionResult Edit(int id)
        {
            GymManagementSystem gymmanagementsystem = context.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }
        [HttpPost]
        public ActionResult Edit(GymManagementSystem gymmanagementsystem)
        {
            if (ModelState.IsValid)
            {
                context.Entry(gymmanagementsystem).State = System.Data.EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(gymmanagementsystem);
        }


    }
}
