﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MyPaisa.Models;

namespace MyPaisa.Controllers
{
    public class MyPaisaController : Controller
    {
        Training_18Jan2017_TalwadeEntities db = new Training_18Jan2017_TalwadeEntities();

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Search()
        {
            var queryDisplayData = from data in db.BillTransaction_121880
                        where data.BillerType=="Electricity" && data.ModeOFPayment=="Credit Card"
                        select data;
            ViewBag.paisadata = queryDisplayData;
            return View();
        }

    }
}
