﻿// Default code generation is disabled for model 'D:\121880_Vinit_Suryarao_Module_4_Set_C\MyPaisa\MyPaisa\Models\Model1.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.