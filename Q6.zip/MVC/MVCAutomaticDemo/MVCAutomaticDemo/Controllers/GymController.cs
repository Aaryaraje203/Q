﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCAutomaticDemo.Models;

namespace MVCAutomaticDemo.Controllers
{
    public class GymController : Controller
    {
        private Training_18Jan2017_TalwadeEntities db = new Training_18Jan2017_TalwadeEntities();

        //
        // GET: /Gym/

        public ActionResult Index()
        {
            return View(db.GymManagementSystems.ToList());
        }

        //
        // GET: /Gym/Details/5

        public ActionResult Details(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // GET: /Gym/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Gym/Create

        [HttpPost]
        public ActionResult Create(GymManagementSystem gymmanagementsystem)
        {
            if (ModelState.IsValid)
            {
                db.GymManagementSystems.Add(gymmanagementsystem);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(gymmanagementsystem);
        }

        //
        // GET: /Gym/Edit/5

        public ActionResult Edit(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // POST: /Gym/Edit/5

        [HttpPost]
        public ActionResult Edit(GymManagementSystem gymmanagementsystem)
        {
            if (ModelState.IsValid)
            {
                db.Entry(gymmanagementsystem).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(gymmanagementsystem);
        }

        //
        // GET: /Gym/Delete/5

        public ActionResult Delete(int id = 0)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            if (gymmanagementsystem == null)
            {
                return HttpNotFound();
            }
            return View(gymmanagementsystem);
        }

        //
        // POST: /Gym/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            GymManagementSystem gymmanagementsystem = db.GymManagementSystems.Find(id);
            db.GymManagementSystems.Remove(gymmanagementsystem);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}