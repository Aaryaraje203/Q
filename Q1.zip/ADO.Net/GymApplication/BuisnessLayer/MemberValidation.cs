﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using Entity;
using CustomException;
using DataAccessLayer;

namespace BuisnessLayer
{

    /// <summary>
    /// Class to validate member Record
    /// Author: 
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description: 
    /// </summary>
    public class MemberValidation
    {
        MembersOperations operationObj = new MembersOperations();

        /// <summary>
        /// Method to validate member record
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="memberObj"></param>
        /// <returns></returns>
        public bool ValidateMembers(Members memberObj)
        {
            bool validMembers = true;
            StringBuilder sb = new StringBuilder();
            if (memberObj.MemberID.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members ID is required.");
            }
            if (memberObj.MemberName.Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Name is required.");
            }
            if (memberObj.ContactNo.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Contact No is required.");
            }
            if (!(Regex.IsMatch(memberObj.MemberID.ToString(), @"^[0-9]+$")))
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members ID should contain only numbers.");
            }
            if (!(Regex.IsMatch(memberObj.MemberName, @"^[a-zA-Z ]+$")))
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Name should contain only characters.");
            }
            if (!(Regex.IsMatch(memberObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            }
            if (memberObj.ContactNo.ToString().Length != 10)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }
            if (memberObj.Membertype.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members type is required.");
            }
            if (validMembers == false)
                throw new MemberException(sb.ToString());
            return validMembers;
        }
        /// <summary>
        /// Method that calls a method that adds a Members Record
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description:
        /// </summary>
        /// <param name="membersObj"></param>
        /// <returns>bool</returns>
        public bool AddMemberRecord(Members  memberObj)
        {
            bool memberAdded = false;
            if (ValidateMembers(memberObj))
                memberAdded = operationObj.AddMemberRecord(memberObj);
            return memberAdded;
        }

        /// <summary>
        /// Method that calls a method that returns the member information
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="memberID"></param>
        /// <returns>DataTable</returns>
        public DataTable GetMemberRecord(int memberID)
        {

            DataTable memberTable = operationObj.GetMemberRecord(memberID);
            return memberTable;
        }

        public DataTable DeleteMember(int memberID)
        {
            DataTable memberTable = operationObj.DeleteMember(memberID);
            return memberTable;
        }

        public bool UpdateRecord(Members gymObj)
        {
            bool gymAdded = false;
            if (ValidateMembers(gymObj))
                gymAdded = operationObj.UpdateRecord(gymObj);
            return gymAdded;
        }
    }
   
}
