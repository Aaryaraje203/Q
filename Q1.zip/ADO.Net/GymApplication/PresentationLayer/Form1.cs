﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using CustomException;
using BuisnessLayer;
using System.Data.SqlClient;

namespace PresentationLayer
{
    public partial class Form1 : Form
    {
        MemberValidation validationObj = new MemberValidation();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Members memberObj = new Members();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtMemberID.Text, out result);
                if (isNumber)
                    memberObj.MemberID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in member ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                memberObj.MemberName = txtMemberName.Text;
                isNumber = long.TryParse(txtContactNo.Text, out contactNo);
                if (isNumber)
                    memberObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                memberObj.Membertype = txtMemberType.Text;

                bool memberAdded = validationObj.AddMemberRecord(memberObj);
                if (memberAdded)
                    MessageBox.Show("member Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add member record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (MemberException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtMemberID.Text, out result);
            if (isNumber)
                memberTable = validationObj.GetMemberRecord(result);
            else
            {
                MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvMember.DataSource = memberTable;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtMemberID.Text, out result);
            if (isNumber)
            {
                memberTable = validationObj.DeleteMember(result);
                MessageBox.Show("Data deleted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            else
            {
                MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvMember.DataSource = memberTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Members gymObj = new Members();
                bool isNumber;
                int result;
                long contactNo;
                isNumber = int.TryParse(txtMemberID.Text, out result);
                if (isNumber)
                    gymObj.MemberID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Member ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                gymObj.MemberName = txtMemberName.Text;
                gymObj.Membertype = txtMemberType.Text;
                isNumber = long.TryParse(txtContactNo.Text, out contactNo);
                if (isNumber)
                    gymObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                bool gymAdded = validationObj.UpdateRecord(gymObj);
                if (gymAdded)
                    MessageBox.Show("Gym Record Ipdated Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to Update gym record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (MemberException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

       

  

      
    }


  

 }
