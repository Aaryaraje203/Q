﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileIOSample_Read_write
{
    /// <summary>
    /// Employee ID       : 121880
    /// Employee Name     : Vinit Suryarao
    /// Description       : This class creates fil, write data into file and read data from file.
    /// Date of Creation  : 28-Feb-2017
    /// </summary>

    class CustomerDetails
    {
        static void Main(string[] args)
        {
            // CustomerDeatails cile is creates with input data
            try
            {
                FileStream fs = new FileStream("CustomerDetails.txt", FileMode.Create, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                sw.WriteLine("This are Customer details for the year 2015-2016. Most of our cutsomer are from east zone.");
                sw.WriteLine(DateTime.Now.ToString());
                sw.Flush();
                fs.Close();
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine(" File is Created Successfully");
            }

            // Data reads from CustomerDetails file
            try
            {
                FileStream fsRead = new FileStream("CustomerDetails.txt", FileMode.Open, FileAccess.Read);
                StreamReader sr = new StreamReader(fsRead);
                string data = sr.ReadToEnd();
                Console.WriteLine(data);
                fsRead.Close();
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Data is Retrieved Successfully");
            }
            Console.ReadKey();
        }
    }
}

