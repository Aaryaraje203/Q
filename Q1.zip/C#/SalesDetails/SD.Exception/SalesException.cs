﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SD.Exception
{
    /// <summary>
    /// Employee ID           : 121880
    /// Employee Name         : Vinit Suryarao
    /// Description           : User defined exception class for Sales Details
    /// Date of Creation      : 27-Feb-2017 
    /// </summary>
    
    public class SalesException : ApplicationException
    {
         //Default Constructor
        public SalesException()
            : base()
        { }

        //Parameterized Constructor
        public SalesException(string message)
            : base(message)
        { }
    }
}
