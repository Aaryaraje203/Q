﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SD.Entity;                        //Reference to the Sales Entity Class
using SD.Exception;                     //Reference to the Sales Exception Class
using SD.DAL;                           //Reference to the Sales Sales Operations Class

namespace SD.BL
{
    /// <summary>
    /// Employee ID           : 121880
    /// Employee Name         : Vinit Suryarao
    /// Description           : Sales Validations class perform the all data validations
    /// Date of Creation      : 27-Feb-2017 
    /// </summary>
    
    public class SalesValidations
    {
        //Method for Validate the Sales Details

        public static bool ValidateSales(Sales sd)
        {
            bool salesValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (sd.salesManCode == null)
                {
                    message.Append("\n Salesman Code Should Not Be Blank. Please Enter Four Digit Salesman Code");
                    salesValidated = false;
                }

                if (sd.salesManCode < 1000 || sd.salesManCode > 9999)
                {
                    message.Append("\n Salesman Code Should Be a Four Digit, Please Enter Four Digit Salesman Code");
                    salesValidated = false;
                }

                if (sd.salesManName == String.Empty)
                {
                    message.Append("\n Salesman Name Should Not Be Blank. Please Enter Proper Salesman Name");
                    salesValidated = false;
                }
                else if (!Regex.IsMatch(sd.salesManName, "[A-Z][a-z]+"))
                {
                    message.Append("\n Salesman Name Should Be Alphabate Only, Please Enter Proper Saleman Name");
                    salesValidated = false;
                }

                if (sd.zone == String.Empty)
                {
                    message.Append("\n Sales Zone Should Not Be Blank, Please Enter Valid Zone");
                    salesValidated = false;
                }
                else if (sd.zone.ToLower() != "indian" && sd.zone.ToLower() != "pacific")
                {
                    message.Append("\n Sales Zone Should Be Indian or Pacific");
                    salesValidated = false;
                }

                if (sd.region == String.Empty)
                {
                    message.Append("\n Sales Region Should Not Be Blank, Please Enter Valid Region");
                    salesValidated = false;
                }
                else if (sd.region.ToLower() != "north" && sd.region.ToLower() != "west" && sd.region.ToLower() != "east" && sd.region.ToLower() != "south")
                {
                    message.Append("\n Sales Region Should Be North, West, East, South");
                    salesValidated = false;
                }


                if (sd.DOS == null)
                {
                    message.Append("\n Date Should Not Be Blank, Please Enter Current Date");
                    salesValidated = false;
                }
                else if (sd.DOS != DateTime.Today)
                {
                    message.Append("\n Date Should Be a Current Date");
                    salesValidated = false;
                }

                if (salesValidated == false)
                {
                    throw new SalesException(message.ToString());
                }
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesValidated;
        }



        //Method for Add Sales Details
        public static bool AddSales(Sales sd)
        {
            bool salesAdded = false;

            try
            {
                if (ValidateSales(sd))
                {
                    salesAdded = SalesOperations.AddSales(sd);
                }
                else
                {
                    throw new SalesException("Sales Details Are Invalid");
                }
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesAdded;
        }

      
        // Method for Display all Sales Details
        public static List<Sales> DisplayAllSales()
        {
            List<Sales> salesList = null;

            try
            {
                salesList = SalesOperations.DisplayAllSales();
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesList;
        }

        // Method For Serialization
        public static bool SerializeSales()
        {
            bool salesSerialized = false;

            try
            {
                salesSerialized = SalesOperations.SerializeSales();
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesSerialized;
        }


        //Method for Deserialzation
        public static List<Sales> DeserializeSales()
        {
            List<Sales> salesList = null;

            try
            {
                salesList = SalesOperations.DeserializeSales();
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesList;
        }
    }
}
