﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SD.Entity;                   //Reference to the Sales Entity Class
using SD.Exception;                //Reference to the Sales Exception Class

namespace SD.DAL
{
    /// <summary>
    /// Employee ID           : 121880
    /// Employee Name         : Vinit Suryarao
    /// Description           : Sales Operations class contains all sales related operations
    /// Date of Creation      : 27-Feb-2017 
    /// </summary>
    
    public class SalesOperations
    {
         static List<Sales> salesList = new List<Sales>();

        //Method for adding new sales record in the Sales List
        public static bool AddSales(Sales sd)
        {
            bool sdAdded = false;

            try 
            {
                //Adding Sales data in list
                salesList.Add(sd);
                sdAdded = true;
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return sdAdded;
        }


        //Method for displaying all sales details
        public static List<Sales> DisplayAllSales()
        {
            return salesList;
        }

       
        // Method for Serialize the Sales Details Class
        public static bool SerializeSales()
        {
            bool salesSerialized = false;

            try 
            {
                if (salesList.Count > 0)
                {
                    FileStream fs = new FileStream("SalesDetails.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, salesList);
                    fs.Close();
                    salesSerialized = true;
                }
                else
                {
                    throw new SalesException("Sales Data Not Found, So Cannot Perform Serialization");
                }
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesSerialized;
        }


        //Method for Deserialize the Sales Details Class
        public static List<Sales> DeserializeSales()
        {
            List<Sales> desSalesList = null;

            try 
            {
                FileStream fs = new FileStream("SalesDetails.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desSalesList = (List<Sales>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (SalesException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desSalesList;
        }
    }
}

    

