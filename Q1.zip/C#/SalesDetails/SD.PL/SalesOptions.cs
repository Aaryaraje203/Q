﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SD.Entity;                 //Reference to the Sales Enitity Class
using SD.Exception;              //Reference to the Sales Exception Class
using SD.BL;                     //Reference to the Sales Validation Class

namespace SD.PL
{
     /// <summary>
    /// Employee ID           : 121880
    /// Employee Name         : Vinit Suryarao
    /// Description           : Sales Class have interaction with user and select operations
    /// Date of Creation      : 27-Feb-2017 
    /// </summary>
    
    class SalesOptions
    {
        //Method for Add Sales Details
        public static void AddSales()
        {
            Sales sd = new Sales();
            try 
            {
                Console.Write("Please Enter Four Digit Salesman Code : ");
                sd.salesManCode = Convert.ToInt32(Console.ReadLine());
                Console.Write("Please Enter Salesman Name            : ");
                sd.salesManName = Console.ReadLine();
                Console.Write("Please Enter Sales Zone               : ");
                sd.zone = Console.ReadLine();
                Console.Write("Please Enter Sales Region             : ");
                sd.region = Console.ReadLine();
                Console.Write("Please Enter the Date                 : ");
                sd.DOS = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Please Enter Product Code             : ");
                sd.prodCode = Convert.ToInt32(Console.ReadLine());
                Console.Write("Please Enter Target Set               : ");
                sd.targetSet = Convert.ToInt32(Console.ReadLine());
                Console.Write("Please Enter Actual Sales             : ");
                sd.actualSales = Convert.ToInt32(Console.ReadLine());
                sd.variation = sd.targetSet - sd.actualSales;
                Console.Write("Please Enter Remarks                  : ");
                sd.remarks = Console.ReadLine();

                bool salesAdded = SalesValidations.AddSales(sd);

                if (salesAdded)
                {
                    Console.WriteLine("Sales Data Added Successfully");
                }
                else
                {
                    throw new SalesException("Problem Occured, Sales Data Not Added");
                }
            }
            catch (SalesException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method For Display Sales Details
        public static void DisplayAllSales()
        {
            try 
            {
                List<Sales> salesList = SalesValidations.DisplayAllSales();

                if (salesList.Count>0)
                {
                    Console.WriteLine("************************************************************************************************************************");
                    Console.WriteLine("Salesman Code   Salesman Name   Zone   Region   Date   Product Code   Target Set   Actual Sales   Variations   Remarks");
                    Console.WriteLine("************************************************************************************************************************");
                    foreach (Sales sd in salesList)
                    {
                        Console.WriteLine(sd.salesManCode + "\t" + sd.salesManName +"\t" + sd.zone +"\t" + sd.region +"\t" + sd.DOS +"\t" + sd.prodCode +"\t" + sd.targetSet +"\t" + sd.actualSales +"\t" + sd.variation +"\t" + sd.remarks);
                    }
                    Console.WriteLine("***************************************************************************************************************************");
                }
                else
                {
                    throw new SalesException("Sales Details List Is Empty");
                }
            }
            catch (SalesException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method For Serialization of Sales Details
        public static void SerializeSales()
        {
            try 
            {
                bool salesSerialized = SalesValidations.SerializeSales();

                if (salesSerialized)
                {
                    Console.WriteLine("Sales Details Data Serialized Successfully");
                }
                else
                {
                    throw new SalesException("Sales Details Data is not Serialized");
                }
            }
            catch (SalesException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Method for Deserialization of Sales Details
        public static void DeserializeSales()
        {
            try
            {
                List<Sales> salesList = SalesValidations.DeserializeSales();

                if (salesList.Count > 0)
                {
                    Console.WriteLine("Sales Details Data Deserialized Successfully");
                    Console.WriteLine("************************************************************************************************************************");
                    Console.WriteLine("Salesman Code   Salesman Name   Zone   Region   Date   Product Code   Target Set   Actual Sales   Variations   Remarks");
                    Console.WriteLine("************************************************************************************************************************");
                    foreach (Sales sd in salesList)
                    {
                        Console.WriteLine(sd.salesManCode + "\t" + sd.salesManName + "\t" + sd.zone + "\t" + sd.region + "\t" + sd.DOS + "\t" + sd.prodCode + "\t" + sd.targetSet + "\t" + sd.actualSales + "\t" + sd.variation + "\t" + sd.remarks);
                    }
                    Console.WriteLine("***************************************************************************************************************************");
                }
                else
                {
                    throw new SalesException("Sales Details Data is not Deserialized");
                }
            }
            catch (SalesException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("*************Sales Details Management System************");
            Console.WriteLine("1. Add Sales Details");
            Console.WriteLine("2. Display All Sales Details");
            Console.WriteLine("3. Serialize Sales");
            Console.WriteLine("4. Deserialize Sales");
            Console.WriteLine("5. Exit");
            Console.WriteLine("*********************************************************");
        }

        static void Main(string[] args)
        {
            int choice = 0;

            try 
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddSales();
                            break;
                        case 2: DisplayAllSales();
                            break;
                        case 3: SerializeSales();
                            break;
                        case 4: DeserializeSales();
                            break;
                        case 5 : Environment.Exit(0);
                            break;
                        default:Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}

