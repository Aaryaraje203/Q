﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SD.Entity
{
    /// <summary>
    /// Employee ID           : 121880
    /// Employee Name         : Vinit Suryarao
    /// Description           : This class will have the Sales Details Structure
    /// Date of Creation      : 27-Feb-2017 
    /// </summary>
    
    [Serializable]            //This class will become Serializable

    public class Sales
    {
        //Get or Set Sales Code
        public int salesManCode { get; set; }

        //Get or Set Salesman Name
        public string salesManName { get; set; }

        //Get or Set Sales Zone
        public string zone { get; set; }

        //Get or Set Sales Region
        public string region { get; set; }

        //Get or Set Date of Sale
        public DateTime DOS { get; set; }

        //Get or Set Product Code
        public int prodCode { get; set; }

        //Get or Set Sales Target Set
        public int targetSet { get; set; }

        //Get or Set Actual Sales
        public int actualSales { get; set; }

        //Get or Set Sales Variation
        public int variation { get; set; }

        //Get or Set Remarks
        public string remarks { get; set; }
        
    }
}
