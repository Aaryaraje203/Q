﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdawithReturn
{
    public delegate int MathDelegate(int num1, int num2);

    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate anonymous = delegate(int num1, int num2) { return num1 + num2; };

            Console.WriteLine("By Anonymous Method : " + anonymous(23, 12));

            MathDelegate lambda = (num1, num2) => {return num1 + num2;};

            Console.WriteLine("By Lambda Expression : " + lambda(34, 56));
        }
    }
}
