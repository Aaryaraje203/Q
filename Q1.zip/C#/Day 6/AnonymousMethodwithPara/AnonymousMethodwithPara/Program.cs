﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodwithPara
{
    public delegate void MathDelegate(int num, int pow);

    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate del = delegate(int num, int pow) 
            {
                Console.WriteLine("{0} ^ {1} is => {2}", num, pow, Math.Pow(num, pow));
            };

            del(3, 6);

            Console.ReadKey();
        }
    }
}
