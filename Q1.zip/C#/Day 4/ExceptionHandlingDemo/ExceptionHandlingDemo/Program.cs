﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, result;
            int[] arr = new int[10];

            try
            {
                Console.Write("Enter Number 1 : ");
                num1 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Number 2 : ");
                num2 = Convert.ToInt32(Console.ReadLine());

                result = num1 / num2;

                arr[3] = 212;
                arr[4] = 234343545;
                arr[12] = 3434;
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("Finally block called");
            }
            Console.ReadKey();

        }
    }
}
