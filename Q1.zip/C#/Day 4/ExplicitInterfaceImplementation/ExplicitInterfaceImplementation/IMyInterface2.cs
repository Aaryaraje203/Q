﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementation
{
    public interface IMyInterface2
    {
        void Show();
        void Print();
    }
}
