﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    /// <summary>
    /// Employee ID       : 121880
    /// Employee Name     : Vinit Suryarao
    /// Description       : This class contains properties for Reflection Library
    /// Date of Creation  : 28-Feb-2017
    /// </summary>
    
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }

    }
}
