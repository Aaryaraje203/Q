﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    /// <summary>
    /// Employee ID       : 121880
    /// Employee Name     : Vinit Suryarao
    /// Description       : This class contains constructors for Reflection Library
    /// Date of Creation  : 28-Feb-2017
    /// </summary>
    
    class PersonalDetails
    {
        PersonalDetails(string firstName)
        {
            Console.WriteLine("First Name is"+firstName);
        }
        PersonalDetails(string firstName, string middleName)
        {
            Console.WriteLine("First Name is" + firstName);
            Console.WriteLine("Middle Name is" + middleName);
        }
        PersonalDetails(string firstName, string middleName, string lastName)
        {
            Console.WriteLine("First Name is" + firstName);
            Console.WriteLine("Middle Name is" + middleName);
            Console.WriteLine("Last Name is" + lastName);
        }

    }
}
