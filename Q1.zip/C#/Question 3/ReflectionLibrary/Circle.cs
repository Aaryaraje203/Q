﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    /// <summary>
    /// Employee ID       : 121880
    /// Employee Name     : Vinit Suryarao
    /// Description       : This class contains method for Reflection Library
    /// Date of Creation  : 28-Feb-2017
    /// </summary>
    
    public class Circle
    {
        double radius=4.5;
        public void Area()
        {
            Console.WriteLine("Area of Cirlce is"+(3.14*radius*radius));

        }
    }
}
