﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    /// <summary>
    /// Employee ID       : 121880
    /// Employee Name     : Vinit Suryarao
    /// Description       : This class contains fields for Reflection Library
    /// Date of Creation  : 28-Feb-2017
    /// </summary>
    
    public class Student
    {
        int studId;
        int mark1;
        int mark2;
        int totalMark;
        string studName;
        string schoolName;

    }
}
