﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace PropertyInfoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");

            Type empType = refAssembly.GetType("ReflectionLibrary.Employee");

            PropertyInfo[] empProp = empType.GetProperties();

            Console.WriteLine("Number of Properties are : " + empProp.Length);
            foreach (PropertyInfo p in empProp)
            {
                Console.WriteLine("*************Property Name : " + p.Name);
                Console.WriteLine("Can Read : " + p.CanRead);
                Console.WriteLine("Can Write : " + p.CanWrite);
                Console.WriteLine("Property Type : " + p.PropertyType.Name);
                Console.WriteLine();
            }

            Object obj = refAssembly.CreateInstance("ReflectionLibrary.Employee");

            PropertyInfo id = empType.GetProperty("EmpID");
            if (id != null)
            {
                id.SetValue(obj, 101);
                Console.WriteLine("Employee ID : " + id.GetValue(obj));
            }
        }
    }
}
