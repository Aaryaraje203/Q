﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    public class Employee
    {
        int empID;

        //Read Only Property
        public int EmployeeID
        {
            get { return empID; }
        }

        string name;

        //Read-Write Property
        public string EmployeeName
        {
            get { return name; }
            set { name = value; }
        }

        DateTime dob;
        //Write Only Property
        public DateTime DOB
        {
            set { dob = value; }
        }

        public Employee(int id)
        {
            this.empID = id;
        }
    }
}
