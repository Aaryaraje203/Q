﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibrary;

namespace MathApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate cal = new Calculate();

            Console.WriteLine("Addition is : " + cal.Addition(12, 45));
            Console.WriteLine("Subtraction is : " + Calculate.Subtraction(43, 11));
            Console.WriteLine("Multiplication is : " + cal.Multiply(12, 3));
            Console.WriteLine("Division is : " + Calculate.Divide(45, 9));
        }
    }
}
