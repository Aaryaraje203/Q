﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;

namespace COMInterOPDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var application = new Microsoft.Office.Interop.Word.Application();

            string fileName = @"D:\DATA\2015\Assignment 1 Shital Patil.docx";

            application.Documents.Open(FileName : fileName);


        }
    }
}
