﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContraVarianceDemoFramework3
{
    public class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public int DeptID { get; set; }

        public Employee(int id, string name, int dept)
        {
            EmpID = id;
            EmpName = name;
            DeptID = dept;
        }
    }

    public class Manager : Employee
    {
        public int Allowance { get; set; }

        public Manager(int id, string name, int dept, int all)
            : base(id, name, dept)
        {
            Allowance = all;
        }
    }

    public class EmployeeComparer : IComparer<Employee>
    {
        int IComparer<Employee>.Compare(Employee x, Employee y)
        {
            if (x.DeptID > y.DeptID)
                return 1;
            else if (x.DeptID == y.DeptID)
                return 0;

            return -1;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            empList.Add(new Employee(101, "Robert", 20));
            empList.Add(new Employee(102, "Sania", 10));
            empList.Add(new Employee(103, "Jenny", 10));
            empList.Add(new Employee(104, "Jason", 30));
            empList.Add(new Employee(105, "Alliser", 20));

            EmployeeComparer empComparer = new EmployeeComparer();
            empList.Sort(empComparer);

            Console.WriteLine("Sorted Employees Are : ");

            empList.ForEach(e => Console.WriteLine("Employee ID : " + e.EmpID + "\tEmployee Name : " + e.EmpName + "\tDepartment ID : " + e.DeptID));

            List<Manager> mgrList = new List<Manager>();

            mgrList.Add(new Manager(201, "Walt", 30, 2000));
            mgrList.Add(new Manager(202, "Tennyson", 10, 2000));
            mgrList.Add(new Manager(203, "Maria", 30, 4000));
            mgrList.Add(new Manager(204, "Joy", 20, 3200));
            mgrList.Add(new Manager(205, "Rosy", 10, 2200));
            mgrList.Add(new Manager(206, "Sofia", 20, 1000));
            mgrList.Add(new Manager(207, "Sylvester", 40, 3000));
            mgrList.Add(new Manager(208, "William", 30, 2500));

            mgrList.Sort(empComparer);

            Console.WriteLine("\n\nSorted Manager List : ");
            mgrList.ForEach(m => Console.WriteLine("Employee ID : " + m.EmpID + "\tEmployee Name : " + m.EmpName + "\tDepartment ID : " + m.DeptID + "\tAllowance : " + m.Allowance));
        }
    }
}
