﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;

namespace EMS.BL
{
    /// <summary>
    /// 
    /// </summary>
    public class EmployeeValidation
    {
        public static bool ValidateEmployee(Employee emp)
        {
            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try 
            {
                if (emp.EmployeeID < 100000 || emp.EmployeeID > 999999)
                {
                    message.Append("Employee ID should have 6 digits only\n");
                    empValidated = false;
                }

                if (emp.EmployeeName == String.Empty)
                {
                    message.Append("Employee Name should be Provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Name should have alphabets only and it should start with capital\n");
                    empValidated = false;
                }

                if (emp.Phone == String.Empty)
                {
                    message.Append("Phone Number should be Provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.Phone, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone Number should have 10 digits exactly and it should start with 7 or 8 or 9\n");
                    empValidated = false;
                }

                if (emp.Age < 18 || emp.Age > 60)
                {
                    message.Append("Age should be withing 18 to 60\n");
                    empValidated = false;
                }

                if (emp.DOJ == null)
                {
                    message.Append("Date of Joining should be provided\n");
                    empValidated = false;
                }
                else if (emp.DOJ > DateTime.Today)
                {
                    message.Append("Date of Joining should be less than or equal to current date\n");
                    empValidated = false;
                }

                if (emp.Location == String.Empty)
                {
                    message.Append("Location should be provided\n");
                    empValidated = false;
                }
                else if (emp.Location.ToLower() != "pune" && emp.Location.ToLower() != "mumbai" && emp.Location.ToLower() != "bangalore")
                {
                    message.Append("Location should be either Pune or Mumbai or Bangalore\n");
                    empValidated = false;
                }

                if (empValidated == false)
                {
                    throw new EmployeeException(message.ToString());
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        public static bool AddEmployee(Employee emp)
        {
            bool empAdded = false;

            try 
            {
                if (ValidateEmployee(emp))
                {
                    empAdded = EmployeeOperations.AddEmployee(emp);
                }
                else
                {
                    throw new EmployeeException("Employee Details are invalid");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empAdded;
        }

        public static bool UpdateEmployee(Employee emp)
        {
            bool empUpdated = false;

            try 
            {
                if (ValidateEmployee(emp))
                {
                    empUpdated = EmployeeOperations.UpdateEmployee(emp);
                }
                else
                {
                    throw new EmployeeException("Employee details are invalid for updation");
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empUpdated;
        }

        public static bool DeleteEmployee(int empID)
        {
            bool empDeleted = false;

            try 
            {
                empDeleted = EmployeeOperations.DeleteEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empDeleted;
        }

        public static List<Employee> DisplayAllEmployee()
        {
            List<Employee> empList = null;

            try 
            {
                empList = EmployeeOperations.DisplayAllEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }

        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try 
            {
                emp = EmployeeOperations.SearchEmployee(empID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }

        public static bool SerializeEmployee()
        {
            bool empSerialized = false;

            try 
            {
                empSerialized = EmployeeOperations.SerializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empSerialized;
        }

        public static List<Employee> DeserializeEmployee()
        {
            List<Employee> empList = null;

            try 
            {
                empList = EmployeeOperations.DeserializeEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empList;
        }
    }
}
