﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for Student
/// </summary>
public class Student
{
	public Student()
	{
		//
		// TODO: Add constructor logic here
		//
       
	}

    private int rollNo;

    public int RollNo
    {
        get { return rollNo; }
        set { rollNo = value; }
    }
    private string name;

    public string Name
    {
        get { return name; }
        set { name = value; }
    }
    private string address;

    public string Address
    {
        get { return address; }
        set { address = value; }
    }

}