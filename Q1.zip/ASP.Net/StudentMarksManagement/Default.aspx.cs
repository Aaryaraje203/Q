﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMM.Entity;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        Student obj = new Student();

        obj.studentName = txtName.Text;
        obj.subject1 = Convert.ToInt32(txtSubject1.Text);
        obj.subject2 = Convert.ToInt32(txtSubject2.Text);
        obj.subject3 = Convert.ToInt32(txtSubject3.Text);
        obj.subject4 = Convert.ToInt32(txtSubject4.Text);
        obj.subject5 = Convert.ToInt32(txtSubject5.Text);

        txtTotalMarks.Text = Convert.ToString(Convert.ToInt32(txtSubject1.Text) + Convert.ToInt32(txtSubject2.Text) + Convert.ToInt32(txtSubject3.Text) + Convert.ToInt32(txtSubject4.Text) + Convert.ToInt32(txtSubject5.Text));

        txtPercentage.Text = Convert.ToString((Convert.ToInt32(txtTotalMarks.Text)/5));

      
    }
}