﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;

namespace DALWebService
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class StudentService : System.Web.Services.WebService
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adap;
        [WebMethod]
        public DataTable FetchAllStudents()
        {
            con = new SqlConnection();
            con.ConnectionString=@"Data Source=NDAMSSQL\SQLILEARN; Initial Catalog=Training_18Jan2017_Talwade; user id=sqluser; password=sqluser";
            adap=new SqlDataAdapter();
            adap.SelectCommand=new SqlCommand();
            adap.SelectCommand.CommandText="Select * from Student";
            adap.SelectCommand.Connection=con;
            DataSet ds=new DataSet();
            adap.MissingSchemaAction=MissingSchemaAction.AddWithKey;
            adap.Fill(ds,"Stud");
            return ds.Tables["Stud"];

        }
    }
}