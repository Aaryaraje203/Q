﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebUI.MyRef;

namespace WebUI
{
    public partial class ShowStudentDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("<h1>" + DateTime.Now.ToString() + "</h1>");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            StudentServiceSoapClient obj = new StudentServiceSoapClient();
            GridView1.DataSource = obj.FetchAllStudents();
            Page.DataBind();
        }
    }
}