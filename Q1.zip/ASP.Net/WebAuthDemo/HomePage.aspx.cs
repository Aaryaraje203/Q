﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.DataSource = Membership.GetAllUsers();
        GridView1.DataBind();
        CheckBoxList1.DataSource = Membership.GetAllUsers();
        CheckBoxList1.DataBind();
        

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.City = "Mumbai";

    }
}