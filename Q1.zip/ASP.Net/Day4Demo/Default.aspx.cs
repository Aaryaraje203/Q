﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int cnt;
        if (!IsPostBack)
        {
            cnt = 0;
            ViewState["MyState"] = cnt;
        }
        else
        {
            cnt = Convert.ToInt32(ViewState["MyState"]);
            cnt++;
            ViewState["MyState"] = cnt;
        }
        Response.Write("\n Number of click is " + cnt);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Write("\n hidden value is"+HiddenField1.Value);
    }
}