﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CookieResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie str = Request.Cookies["DemoCookie5"];
        Label1.Text = str.Value;
        HttpCookie str2 = Request.Cookies["DemoCookie5"];
        Label2.Text = str2.Value;
       
    }
}
