﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PostBackDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("<h1>IsPostBack :- "+IsPostBack.ToString()+"</h1>");
        if (!IsPostBack)
        {
            DropDownList1.Items.Add("Mumbai");
            DropDownList1.Items.Add("Pune");
            DropDownList1.Items.Add("Hydrabad");
            DropDownList1.Items.Add("Banglore");
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        TextBox2.Visible = true;
        Label1.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text +" Lives in "+ DropDownList1.SelectedItem.Text;
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        TextBox1.Text = TextBox1.Text + " Lives in " + DropDownList1.SelectedItem.Text;
    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        TextBox3.Visible = true;
        Label2.Visible = true;
    }
}
