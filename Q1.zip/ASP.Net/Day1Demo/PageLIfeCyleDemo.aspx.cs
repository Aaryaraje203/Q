﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PageLIfeCyleDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("We are in Page Load Event <br/>");
    }
    protected void Page_PreInIt(object sender, EventArgs e)
    {
        Response.Write("We are in Page Pre Init Event <br/>");
    }
    protected void Page_InIt(object sender, EventArgs e)
    {
        Response.Write("We are in Page Load Init <br/>");
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        Response.Write("We are in Page Load PreRender <br/>");
    }
    
}