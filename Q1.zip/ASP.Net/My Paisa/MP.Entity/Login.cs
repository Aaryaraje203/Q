﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP.Entity
{
    /// <summary>
    /// Class Name           :- Entity to store login Information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 31st march 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    public class Login
    {
        /// <summary>
        /// Property to store and retrieve UserName
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Property to store and retrieve Password
        /// </summary>
        public string Password { get; set; }
    }
}
