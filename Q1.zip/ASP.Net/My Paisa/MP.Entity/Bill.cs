﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP.Entity
{
   
    
         /// <summary>
         /// Class Name           :- Entity to store bill transaction Information
         /// Author               :- Vinit Suryarao
         /// Date Modified        :- 31st march 2017
         /// Version No           :- 1.0
         /// Change Description   :- None
         /// </summary>
    public class Bill
    {
        /// <summary>
        /// Property to store and retrieve TransactionID
        /// </summary>
        public int TransactionID { get; set; }


        /// <summary>
        /// Property to store and retrieve MobileNo
        /// </summary>
        public long MobileNo { get; set; }


         /// <summary>
        /// Property to store and retrieve BillerTYpe
        /// </summary>
        public string BillerTYpe{ get; set; }


        /// <summary>
        /// Property to store and retrieve ConsumerID
        /// </summary>
        public int ConsumerID { get; set; }


        /// <summary>
        /// Property to store and retrieve BillDate
        /// </summary>
        public DateTime BillDate{ get; set; }


         /// <summary>
        /// Property to store and retrieve PaymentDate
        /// </summary>
        public DateTime PaymentDate{ get; set; }


        /// <summary>
        /// Property to store and retrieve ModeOfPayment
        /// </summary>
        public string ModeOfPayment { get; set; }

        /// <summary>
        /// Property to store and retrieve Number
        /// </summary>
        public int Number { get; set; }


        /// <summary>
        /// Property to store and retrieve BillAmount
        /// </summary>
        public int BillAmount { get; set; }
    }
}

    

