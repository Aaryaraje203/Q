﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MP.Entity;
using MP.BL;
using MP.Exception;
using System.Data.SqlClient;

namespace MP.PL
{
    public partial class PayBill : System.Web.UI.Page
    {
        BillValidation validationObj=new BillValidation();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                lbluser.Text = "Welcome To My-Paisa " + Session["user"].ToString() + " Centralized Payment Portal";
            }

        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            try
           {
                Bill bill = new Bill();
                bill.BillerTYpe=DropDownListBiller.SelectedValue.ToString();
                bill.ConsumerID=Convert.ToInt32(txtConsumerID.Text);
                bill.MobileNo=Convert.ToInt64(txtMobNo.Text);
                bill.BillDate = Convert.ToDateTime(txtBillDate.Text);
                bill.PaymentDate = Convert.ToDateTime(txtPayDate.Text);
                bill.ModeOfPayment=DropDownListMode.SelectedValue.ToString();
                if (DropDownListMode.SelectedValue.ToString() == "Cheque")
                {
                    
                    txtNumber.Text = "Cheque Number";
                }
                else if (DropDownListMode.SelectedValue.ToString() == "Credit Card")
                {
                    lablNumber.Text = "Credit Card Number";
                }
                else
                    if (DropDownListMode.SelectedValue.ToString() == "Debit Card")
                    {
                        
                        lablNumber.Text = "Debit Card Number";
                    }
                bill.Number = Convert.ToInt32(txtNumber.Text);
                bill.BillAmount=Convert.ToInt32(txtAmount.Text);


                bool memberAdded = validationObj.AddRecord(bill);
                if (memberAdded)
                {
                    Response.Redirect("Success.aspx");
                }
                else
                {
                    Label10.Visible = true;
                    Label10.Text = "Payment Is Not Successfull";
                }

            }
            catch (BillException ex)
            {
                Label10.Visible = true;
                Label10.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label10.Visible = true;
                Label10.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Label10.Visible = true;
                Label10.Text = ex.Message;
            }
        }

        protected void DropDownListMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
        }
        }
    }
