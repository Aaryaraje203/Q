﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MP.Entity;
using MP.Exception;
using MP.BL;
using System.Data;


namespace MP.PL
{
    public partial class Login : System.Web.UI.Page
    {
        LoginValidation validationObj=new LoginValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           DataTable memberTable = new DataTable();
            
                try
                {
                    memberTable = validationObj.SearchRecord(txtUserName.Text, txtPassword.Text);
                    if (memberTable.Rows[0]["UserName"] == null || memberTable.Rows[0]["UserName"] == string.Empty)
                    {
                        Label3.Visible = true;
                        Label3.Text = "UserName/Password is Invalid";
                    }
                    else
                    {
                        Session["user"] = memberTable.Rows[0]["UserName"];
                        Response.Redirect("PayBill.aspx");
                    }
                }
            catch
                {
                    Label3.Visible = true;
                    Label3.Text = "UserName/Password is Invalid";
            }
               
            }
            
        }
    }
