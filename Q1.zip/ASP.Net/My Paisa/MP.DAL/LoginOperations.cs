﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using MP.Entity;
using MP.Exception;

namespace MP.DAL
{
    public class LoginOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public LoginOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MyPaisaApp"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        public DataTable ValidateUser(string UserName, string Password)
        {
            try
            {

                SqlCommand cmdGetMember = new SqlCommand("ValidateUser", connection);
                cmdGetMember.CommandType = CommandType.StoredProcedure;
                cmdGetMember.Parameters.AddWithValue("@UserName", UserName);
                cmdGetMember.Parameters.AddWithValue("@Password", Password);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetMember.ExecuteReader();
                DataTable memberTable = new DataTable();
                memberTable.Load(reader);
                return memberTable;
            }
            catch (BillException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
