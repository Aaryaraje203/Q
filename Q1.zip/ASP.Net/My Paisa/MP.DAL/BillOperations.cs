﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using MP.Entity;
using MP.Exception;

namespace MP.DAL
{
    public class BillOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public BillOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MyPaisaApp"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
       
        public bool AddRecord(Bill bill)
        {
            try
            {
                bool memberAdded = false;
                SqlCommand cmdAdd = new SqlCommand("USP_AddBillDetails", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@MobileNo", bill.MobileNo);
                cmdAdd.Parameters.AddWithValue("@BillerType", bill.BillerTYpe);
                cmdAdd.Parameters.AddWithValue("@ConsumerID", bill.ConsumerID);
                cmdAdd.Parameters.AddWithValue("@BillDate", bill.BillDate);
                cmdAdd.Parameters.AddWithValue("@PaymentDate", bill.PaymentDate);
                cmdAdd.Parameters.AddWithValue("@ModeOfPayment", bill.ModeOfPayment);
                cmdAdd.Parameters.AddWithValue("@Number", bill.Number);
                cmdAdd.Parameters.AddWithValue("@BillAmount", bill.BillAmount);
               
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    memberAdded = true;
                return memberAdded;
            }
            catch (BillException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
       
    }
}
