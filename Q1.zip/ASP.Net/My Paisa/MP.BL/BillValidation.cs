﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MP.Entity;
using MP.Exception;
using MP.DAL;


namespace MP.BL
{
    public class BillValidation
    {
        BillOperations operationObj = new BillOperations();

       
        public bool ValidateMembers(Bill bill)
        {
            bool validMembers = true;
            StringBuilder sb = new StringBuilder();

            if (Convert.ToString(bill.ConsumerID).Length > 12)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Consumer ID Must Not More than 10 Digit");
            }
            if (Convert.ToString(bill.MobileNo).Length > 10)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Mobile Number Must Not More than 10 Digit");
            }

            if (Convert.ToDateTime(bill.BillDate) > DateTime.Today)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Bill Date Must Not Greater Than Current Date");
            }
            if (Convert.ToDateTime(bill.PaymentDate) < DateTime.Today)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Payment Date must Not Less Than Current Date");
            }
           
            if (validMembers == false)
                throw new BillException(sb.ToString());
            return validMembers;
        }
       
        public bool AddRecord(Bill bill)
        {
            bool memberAdded = false;
            if (ValidateMembers(bill))
                memberAdded = operationObj.AddRecord(bill);
            return memberAdded;
        }
    }
}
