﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MP.Entity;
using MP.Exception;
using MP.DAL;
using System.Data;

namespace MP.BL
{
    public class LoginValidation
    {
        LoginOperations operationObj = new LoginOperations();
        public DataTable SearchRecord(string UserName, string Password)
        {
            DataTable memberTable = operationObj.ValidateUser(UserName, Password);
            return memberTable;
        }
    }
}
