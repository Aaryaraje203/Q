﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP.Exception
{
    /// <summary>
    /// Class Name           :- Entity to store Bill Exception Information
    /// Author               :- Vinit Suryarao
    /// Date Modified        :- 31st march 2017
    /// Version No           :- 1.0
    /// Change Description   :- None
    /// </summary>
    public class BillException:ApplicationException
    {
        public BillException() : base() { }
        public BillException(string message) : base(message) { }
    }
}
