CREATE TABLE BillTransaction_121880
(
	TransactionID      int      PRIMARY KEY IDENTITY(1,1),
	MobileNo           bigint,
	BillerType         varchar(30),
	ConsumerID         int,					
	BillDate           DateTime,
	PaymentDate        DateTime,
	ModeOFPayment      varchar(30),
	Number             int,
	BillAmount         int
);   



ALTER PROCEDURE USP_AddBillDetails
(
	@MobileNo           bigint,
	@BillerType         varchar(30),
	@ConsumerID         int,					
	@BillDate           DateTime,
	@PaymentDate       DateTime,
	@ModeOFPayment      varchar(30),
	@Number             int,
	@BillAmount         int
)
AS
BEGIN
		INSERT INTO BillTransaction_121880 (MobileNo   ,      
	                                        BillerType ,      
											ConsumerID,        					
											BillDate,           
											PaymentDate,        
											ModeOFPayment, 
											Number,     
											BillAmount )
											Values( @MobileNo   ,      
	                                        @BillerType ,      
											@ConsumerID,        					
											@BillDate,           
											@PaymentDate,        
											@ModeOFPayment,
											@Number,      
											@BillAmount )
END 

EXEC USP_AddBillDetails 9598959895,Electricity,121880,'05/05/2015','05/05/2015', 'Credit Card',124578,500

select * from BillTransaction_121880

Create Table MyPaisaLogin
(
	UserName varchar(20),
	Password varchar(20)

);


Insert Into MyPaisaLogin Values('admin','admin');

CREATE PROCEDURE ValidateMyPaisaUser
(
		@username varchar(20),
		@password varchar(20)
)
As
Begin
		SELECT UserName from MyPaisaLogin
		Where UserName=@username AND Password=@password;
End

EXEC ValidateMyPaisaUser admin,admin