﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class ModelBindingDemo : System.Web.UI.Page
{
    public List<Student> FetchAllStudent()
    {
        SqlConnection con=new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["Training_18Jan2017_TalwadeConnectionString"].ConnectionString;
        SqlDataAdapter adap = new SqlDataAdapter("Select * from student", con);
       // adap.SelectCommand.CommandText = "Select * from student";
       // adap.SelectCommand.Connection = con;
        DataSet ds = new DataSet();
        adap.Fill(ds, "Stud");
        List<Student> myStud = new List<Student>();
        foreach  (DataRow item in ds.Tables[0].Rows)
        {
            Student s1 = new Student();
            s1.StudentID = Int32.Parse(item[0].ToString());
            s1.StudentName = item[1].ToString();
            s1.City = item[2].ToString();
            myStud.Add(s1);
        }
        return myStud;


    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}