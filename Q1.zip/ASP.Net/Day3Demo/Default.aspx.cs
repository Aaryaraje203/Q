﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader sdr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection();
        con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser"; 
        con.Open();
        cmd = new SqlCommand("Select * from EmployeeDetails", con);
        sdr=cmd.ExecuteReader();
        DataTable myDt=new DataTable();
        myDt.Load(sdr);

        GridView1.DataSource=myDt;
        GridView1.DataBind();
        con.Close();

    }
}