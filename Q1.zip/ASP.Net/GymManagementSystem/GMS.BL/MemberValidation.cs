﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using GMS.Entity;
using GMS.Exception;
using GMS.DAL;

namespace GMS.BL
{

    /// <summary>
    /// Class to validate member Record
    /// Author: 
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description: 
    /// </summary>
    public class MemberValidation
    {
        MembersOperations operationObj = new MembersOperations();

        /// <summary>
        /// Method to validate member record
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="memberObj"></param>
        /// <returns></returns>
        public bool ValidateMembers(Member memberObj)
        {
            bool validMembers = true;
            StringBuilder sb = new StringBuilder();
           
            if (memberObj.MemberName.Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Name is required.");
            }
            if (memberObj.ContactNo.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Contact No is required.");
            }
            
            if (!(Regex.IsMatch(memberObj.MemberName, @"^[a-zA-Z ]+$")))
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members Name should contain only characters.");
            }
            if (!(Regex.IsMatch(memberObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            }
            if (memberObj.ContactNo.ToString().Length != 10)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }
            if (memberObj.Membertype.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Members type is required.");
            }
            if (memberObj.Gender.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + "Gender is required.");
            }
            if (memberObj.Branch.ToString().Length == 0)
            {
                validMembers = false;
                sb.Append(Environment.NewLine + " Branch is required.");
            }
            if (validMembers == false)
                throw new MemberException(sb.ToString());
            return validMembers;
        }
        /// <summary>
        /// Method that calls a method that adds a Members Record
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description:
        /// </summary>
        /// <param name="membersObj"></param>
        /// <returns>bool</returns>
        public bool AddRecord(Member memberObj)
        {
            bool memberAdded = false;
            if (ValidateMembers(memberObj))
                memberAdded = operationObj.AddRecord(memberObj);
            return memberAdded;
        }

        /// <summary>
        /// Method that calls a method that returns the member information
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="memberID"></param>
        /// <returns>DataTable</returns>
        public DataTable SearchRecord(int memberID)
        {

            DataTable memberTable = operationObj.SearchRecord(memberID);
            return memberTable;
        }

        //public DataTable DisplayAllData()
        //{

        //    DataTable memberTable = operationObj.DisplayAllData();
        //    return memberTable;
        //}

        public DataTable DeleteRecord(int memberID)
        {
            DataTable memberTable = operationObj.DeleteRecord(memberID);
            return memberTable;
        }

        public bool UpdateRecord(Member gymObj)
        {
            bool gymAdded = false;
            if (ValidateMembers(gymObj))
                gymAdded = operationObj.UpdateRecord(gymObj);
            return gymAdded;
        }
    }

}
