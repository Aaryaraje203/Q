﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using GMS.Entity;
using GMS.Exception;
using GMS.DAL;

namespace GMS.BL
{
    public class LoginValidation
    {
        LoginOperations operationObj=new LoginOperations();
        public DataTable SearchRecord(string UserName, string Password)
        {
            DataTable memberTable = operationObj.ValidateUser(UserName, Password);
            return memberTable;
        }
    }
}
