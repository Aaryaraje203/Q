﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GMS.Exception
{
    /// <summary>
    /// Class Name           :- Entity to store gym members Information
    /// Author               :-
    /// Date Modified        :- 8th march 2017
    /// Version No           :-
    /// Change Description   :-
    /// </summary>

    public class MemberException : ApplicationException
    {
        public MemberException() : base() { }
        public MemberException(string message) : base(message) { }
    }
}