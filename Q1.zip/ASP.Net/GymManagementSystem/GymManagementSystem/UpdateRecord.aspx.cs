﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;
using System.Data;

namespace GymManagementSystem
{
    public partial class UpdateRecord : System.Web.UI.Page
    {
        MemberValidation validationObj = new MemberValidation();
        Member obj = new Member();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(TextBox6.Text, out result);
            if (isNumber)
            {
                try
                {
                    memberTable = validationObj.SearchRecord(result);
                    Label1.Visible = true;
                    Label1.Text = "Data Fetch Successfully";
                }
                catch
                {
                    Label1.Visible = true;
                    Label1.Text = "Data Not Found";
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Please Enter Integer Member ID";
                return;
            }

            TextBox6.Text = memberTable.Rows[0]["MemberID"].ToString();
            TextBox1.Text = memberTable.Rows[0]["MemberName"].ToString();
            TextBox2.Text = memberTable.Rows[0]["MemberType"].ToString();
            TextBox3.Text = memberTable.Rows[0]["ContactNO"].ToString();
            TextBox4.Text = memberTable.Rows[0]["Gender"].ToString();
            TextBox5.Text = memberTable.Rows[0]["Branch"].ToString();
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                Member memberObj = new Member();
                memberObj.MemberID=Convert.ToInt32(TextBox6.Text);
                memberObj.MemberName = TextBox1.Text;
                memberObj.ContactNo = Convert.ToInt64(TextBox3.Text);
                memberObj.Membertype = TextBox2.Text;
                memberObj.Gender = TextBox4.Text;
                memberObj.Branch = TextBox5.Text;

                bool memberAdded = validationObj.UpdateRecord(memberObj);
                if (memberAdded)
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Updated Succesfully";
                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "Record Not Updated Succesfully";
                }

            }
            catch (MemberException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
            catch (Exception ex)
            {
                Label1.Visible = true;
                Label1.Text = ex.Message;
            }
        }
    }
}