﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;
using System.Data;


namespace GymManagementSystem
{
    public partial class DeleteRecord : System.Web.UI.Page
    {
        MemberValidation validationObj = new MemberValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(TextBox1.Text, out result);
            if (isNumber)
            {
                memberTable = validationObj.DeleteRecord(result);
                Label1.Visible = true;
                Label1.Text = "Data Deleted Successfully";
               
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Data Not Deleted Successfully";
                return;
            }
           
        }
    }
}