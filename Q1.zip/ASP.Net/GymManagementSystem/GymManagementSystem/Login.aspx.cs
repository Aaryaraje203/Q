﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;
using System.Data;

namespace GymManagementSystem
{
    public partial class Login : System.Web.UI.Page
    {
        LoginValidation validationObj = new LoginValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            
                try
                {
                    memberTable = validationObj.SearchRecord(txtUserName.Text, txtPassword.Text);
                    if (memberTable.Rows[0]["UserName"] == null || memberTable.Rows[0]["UserName"] == string.Empty)
                    {
                        Label1.Visible = true;
                        Label1.Text = "UserName/Password is Invalid";
                    }
                    else
                    {
                        Response.Redirect("DisplayAllData.aspx");
                    }
                }
            catch
                {
                    Label1.Visible = true;
                    Label1.Text = "UserName/Password is Invalid";
            }
               
            }
            
        }
    }
