﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;
using System.Data;

namespace GymManagementSystem
{
    public partial class SearchRecord : System.Web.UI.Page
    {
        MemberValidation validationObj = new MemberValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable memberTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(TextBox1.Text, out result);
            if (isNumber)
            {
                try
                {
                    memberTable = validationObj.SearchRecord(result);
                    Label13.Visible = true;
                    Label13.Text = "Data Fetch Successfully";
                }
                catch
                {
                    Label13.Visible = true;
                    Label13.Text = "Data Not Found";
                }
            }
            else
            {
                Label13.Visible = true;
                Label13.Text = "Please Enter Integer Member ID";
                return;
            }
            Label1.Visible = true;
            Label2.Visible = true;
            Label3.Visible = true;
            Label4.Visible = true;
            Label5.Visible = true;
            Label6.Visible = true;
            Label7.Visible = true;
            Label8.Visible = true;
            Label9.Visible = true;
            Label10.Visible = true;
            Label11.Visible = true;
            Label12.Visible = true;
            Label2.Text = memberTable.Rows[0]["MemberID"].ToString();
            Label8.Text = memberTable.Rows[0]["MemberName"].ToString();
            Label10.Text = memberTable.Rows[0]["MemberType"].ToString();
            Label9.Text = memberTable.Rows[0]["ContactNO"].ToString();
            Label11.Text = memberTable.Rows[0]["Gender"].ToString();
            Label12.Text = memberTable.Rows[0]["Branch"].ToString();
        }
    }
}