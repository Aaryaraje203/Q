﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GMS.Entity;
using GMS.BL;
using GMS.Exception;
using System.Data.SqlClient;


namespace GymManagementSystem
{
    public partial class AddRecord : System.Web.UI.Page
    {
        MemberValidation validationObj = new MemberValidation();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           try
           {
                Member memberObj = new Member();
                memberObj.MemberName = TextBox1.Text;
                memberObj.ContactNo =Convert.ToInt64(TextBox2.Text);
                memberObj.Membertype = DropDownList1.SelectedValue.ToString();
                memberObj.Gender = RadioButtonList1.SelectedValue.ToString();
                memberObj.Branch = TextBox3.Text;

                bool memberAdded = validationObj.AddRecord(memberObj);
                if (memberAdded)
                {
                    Label7.Visible = true;
                    Label7.Text = "Record Added Succesfully";
                }
                else
                {
                    Label7.Visible = true;
                    Label7.Text = "Record Not Added Succesfully";
                }

            }
            catch (MemberException ex)
            {
                Label7.Visible = true;
                Label7.Text = ex.Message;
            }
            catch (SqlException ex)
            {
                Label7.Visible = true;
                Label7.Text = ex.Message;
            }
            catch (Exception ex)
            {
                Label7.Visible = true;
                Label7.Text = ex.Message;
            }
        }
    }
}