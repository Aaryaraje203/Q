CREATE TABLE GymManagementSystem
(
	MemberID int IDENTITY(1,1) Primary Key,
	MemberName Varchar(20),
	ContactNO Bigint,
	MemberType Varchar(20),
	Gender varchar(20),
	Branch varchar(20));

	select * from GymManagementSystem

insert into GymManagementSystem ( membername, contactno, membertype,gender,branch) values('Vinit',9967566673,'Heavy','Male','thane');

select * from GymManagementSystem
ALTER PROCEDURE AddGymRecord_SP
(
	@memberName varchar(20),
	@contactNo  bigint,
	@memberType varchar(20),
	@gender varchar(20),
	@branch varchar(20)
)
as
Begin
		INSERT INTO GymManagementSystem(MemberName,ContactNo,MemberType,Gender,Branch) values(@memberName,@contactNo,@memberType,@gender,@branch)
end

EXEC AddGymRecord_SP TTT,9898989898,TTT,TTT,TTT

CREATE PROCEDURE UpdateGymRecord_SP
(
	@memberID int,
	@memberName varchar(20),
	@contactNo  bigint,
	@memberType varchar(20),
	@gender varchar(20),
	@branch varchar(20)
)
as
Begin
		UPDATE GymManagementSystem SET 
		MemberName=@memberName, 
		ContactNo=@contactNo,
		MemberType=@memberType,
		Gender=@gender,
		Branch=@branch
		WHERE MemberID=@memberID;
end

EXEC UpdateGymRecord_SP 16,Vinit,8888888888,VVV,VVV,VVV

CREATE PROCEDURE DeleteGymRecord_SP
(
	@memberID int
)
as
Begin
		Delete FROM GymManagementSystem WHERE MemberID=@memberID;
end

EXEC DeleteGymRecord_SP 16

CREATE PROCEDURE SearchGymRecord_SP
(
	@memberID int
	
)
as
Begin
		SELECT * FROM GymManagementSystem
		WHERE MemberID=@memberID;
end

EXEC SearchGymRecord_SP 14


Create Table GymLogin
(
	UserName varchar(20),
	Password varchar(20)

);

Insert Into GymLogin Values('Vinit','Vinit123');

CREATE PROCEDURE ValidateUser
(
		@username varchar(20),
		@password varchar(20)
)
As
Begin
		SELECT UserName from GymLogin
		Where UserName=@username AND Password=@password;
End

EXEC ValidateUser Vinit,Vinit123