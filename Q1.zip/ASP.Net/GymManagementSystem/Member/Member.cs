﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GMS.Entity
{
    /// <summary>
    /// Class Name           :- Entity to store gym members Information
    /// Author               :-
    /// Date Modified        :- 8th march 2017
    /// Version No           :-
    /// Change Description   :-
    /// </summary>
    public class Member
    {
        /// <summary>
        /// Property to store and retrieve MemberID
        /// </summary>
        public int MemberID { get; set; }
        /// <summary>
        /// Property to store and retrieve MemberName
        /// </summary>
        public string MemberName { get; set; }
        /// <summary>
        /// Property to store and retrieve MemberContactNo
        /// </summary>
        public long ContactNo { get; set; }
        /// <summary>
        /// Property to store and retrieve MemberType
        /// </summary>
        public string Membertype { get; set; }
        /// <summary>
        /// Property to store and retrieve Gender
        /// </summary>
        public string Gender { get; set; }
        /// <summary>
        /// Property to store and retrieve Branch
        /// </summary>
        public string Branch { get; set; }
    }
}
