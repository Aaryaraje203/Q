﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using GMS.Entity;
using GMS.Exception;

namespace GMS.DAL
{

    /// <summary>
    /// Class containing database code
    /// Author: 
    /// Date Modified: 8th march 2017
    /// Version No:
    /// Change Description:
    /// </summary>
    public class MembersOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public MembersOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["GymManagementSystem"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add member record
        /// Author: 
        /// Date Modified: 8th march 2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="memberObj"></param>
        /// <returns>bool</returns>
        public bool AddRecord(Member memberObj)
        {
            try
            {
                bool memberAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddGymRecord_SP", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@memberName", memberObj.MemberName);
                cmdAdd.Parameters.AddWithValue("@contactNo", memberObj.ContactNo);
                cmdAdd.Parameters.AddWithValue("@memberType", memberObj.Membertype);
                cmdAdd.Parameters.AddWithValue("@gender", memberObj.Gender);
                cmdAdd.Parameters.AddWithValue("@branch", memberObj.Branch);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    memberAdded = true;
                return memberAdded;
            }
            catch (MemberException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Method to return member information
        /// Author:
        /// Date Modified: 8th march 2017
        /// Version No: 
        /// </summary>
        /// <param name="memberID"></param>
        /// <returns></returns>
        public DataTable SearchRecord(int memberID)
        {
            try
            {

                SqlCommand cmdGetMember = new SqlCommand("SearchGymRecord_SP", connection);
                cmdGetMember.CommandType = CommandType.StoredProcedure;
                cmdGetMember.Parameters.AddWithValue("@memberID", memberID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetMember.ExecuteReader();
                DataTable memberTable = new DataTable();
                memberTable.Load(reader);
                return memberTable;
            }
            catch (MemberException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable DeleteRecord(int memberID)
        {
            try
            {
                SqlCommand cmdDelete = new SqlCommand("DeleteGymRecord_SP", connection);
                cmdDelete.CommandType = CommandType.StoredProcedure;
                cmdDelete.Parameters.AddWithValue("@memberID", memberID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdDelete.ExecuteReader();
                DataTable memberTable = new DataTable();
                memberTable.Load(reader);
                return memberTable;
            }
            catch (MemberException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }

        }
        public bool UpdateRecord(Member gymObj)
        {
            try
            {
                bool gymAdded = false;
                SqlCommand cmdAdd = new SqlCommand("UpdateGymRecord_SP", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@memberID", gymObj.MemberID);
                cmdAdd.Parameters.AddWithValue("@memberName", gymObj.MemberName);
                cmdAdd.Parameters.AddWithValue("@contactNo", gymObj.ContactNo);
                cmdAdd.Parameters.AddWithValue("@memberType", gymObj.Membertype);
                cmdAdd.Parameters.AddWithValue("@gender", gymObj.Gender);
                cmdAdd.Parameters.AddWithValue("@branch", gymObj.Branch);
                connection.Open();

                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    gymAdded = true;
                return gymAdded;
            }
            catch (MemberException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}