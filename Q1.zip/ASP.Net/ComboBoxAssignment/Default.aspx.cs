﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Items.Add("India");
            DropDownList1.Items.Add("Bhutan");
            DropDownList1.Items.Add("Nepal");
            DropDownList1.Items.Add("China");
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Visible = true;
        DropDownList2.Visible = true;
        DropDownList2.Items.Add("Maharashtra");
        DropDownList2.Items.Add("Goa");
        DropDownList2.Items.Add("Banglore");
        DropDownList2.Items.Add("Hydrabad");
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label3.Visible = true;
        DropDownList3.Visible = true;
        DropDownList3.Items.Add("Mavi Mumbai");
        DropDownList3.Items.Add("Mumbai");
        DropDownList3.Items.Add("Panvel");
        DropDownList3.Items.Add("Thane");
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label4.Visible = true;
        DropDownList4.Visible = true;
        DropDownList4.Items.Add("Airoli");
        DropDownList4.Items.Add("Rabale");
        DropDownList4.Items.Add("Ghansoli");
        DropDownList4.Items.Add("Kopar Khairne");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox2.Text = "Mr." + TextBox1.Text + " Lives in " + " Country " + DropDownList1.SelectedItem.Text + " in State " + DropDownList2.SelectedItem.Text + " in City " + DropDownList3.SelectedItem.Text + " in Railway station " + DropDownList4.SelectedItem.Text;
    }
}