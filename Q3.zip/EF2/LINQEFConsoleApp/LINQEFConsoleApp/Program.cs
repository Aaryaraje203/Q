﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQEFConsoleApp
{
    public class FirstPart
    {
        public void LinqOperationsPartOne()
        {
            Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();
            // Display Data From Staff_Master
            var query1 = from s in context.Staff_Master
                         select s;

            foreach (var item in query1)
            {
                Console.WriteLine("\n*********************************************");
                Console.WriteLine("Display Data From Staff_Master");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Staff Code :- " + item.Staff_Code);
                Console.WriteLine("Name       :- " + item.Staff_Name);
                Console.WriteLine("HIre Date  :- " + item.Hiredate);
            }


            //Display Data Whos Salary More than 30000
            var query2 = from staff in context.Staff_Master
                         where staff.Salary > 30000
                         select staff;

            foreach (var item in query2)
            {
                Console.WriteLine("\n*********************************************");
                Console.WriteLine("Display DataWHos Salary More than 30000");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Staff Code :- " + item.Staff_Code);
                Console.WriteLine("Name       :- " + item.Staff_Name);
                Console.WriteLine("Salary     :- " + item.Salary);
            }

            //Display List Of Student whos city is not null
            var query3 = from student in context.Student_master
                         where student.Address != null
                         select student;


            foreach (var item in query3)
            {
                Console.WriteLine("\n*********************************************");
                Console.WriteLine("Display List Of Student whos city is not null");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Student Code :- " + item.Stud_Code);
                Console.WriteLine("Name         :- " + item.Stud_Name);
                Console.WriteLine("Address      :- " + item.Address);
            }

            //Display List Of Student 
            var query4 = from student in context.Student_master
                         select student;


            foreach (var item in query4)
            {
                Console.WriteLine("\n*********************************************");
                Console.WriteLine("Display List Of Student ");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Student Name    :- " + item.Stud_Name);
                Console.WriteLine("Department Code :- " + item.Dept_Code);
                Console.WriteLine("Date OF Birth   :- " + item.Stud_Dob);
            }

            //Display the count of student which from Banglore
            var query5 = (from student in context.Student_master
                          where student.Address == "Bangalore"
                          select student).Count();

            Console.WriteLine("\n Total Number of Student From banglore is :- " + query5);

            // Display Employees Whos Salary more than Avg salary

            var query6 = from staff in context.Staff_Master
                         where staff.Salary > ((from staf in context.Staff_Master
                                                select staf.Salary).Average())
                         select staff;

            foreach (var item in query6)
            {
                Console.WriteLine("\n*********************************************");
                Console.WriteLine(" Display Employees Whos Salary more than Avg salary ");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Staff Code      :- " + item.Staff_Code);
                Console.WriteLine("Staff Name      :- " + item.Staff_Name);
                Console.WriteLine("Salary          :- " + item.Salary);
            }
            
        }
    }

    public class CRUDOperations
    {
        public void AddOperation()
        {
            Training_18Jan2017_TalwadeEntities context = new Training_18Jan2017_TalwadeEntities();

            // Initializing student object
            Student_master student = new Student_master
            {
                Stud_Code = Convert.ToDecimal("9967"),
                Stud_Name = "Vinit",
                Dept_Code = Convert.ToDecimal("12"),
                Stud_Dob = Convert.ToDateTime("12/05/1994"),
                Address = "Mumbai"
            };
            try
            {

                //Add data to databse
                context.Student_master.Add(student);

                //Changes are saved to db
                context.SaveChanges();
                Console.WriteLine("Data Added Succesfully");
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
                if (e.InnerException != null)
                {
                    Console.WriteLine("Inner Exception");
                    Console.WriteLine(String.Concat(e.InnerException.StackTrace, e.InnerException.Message));
                }
            }
        
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            
            FirstPart obj = new FirstPart();
            //obj.LinqOperationsPartOne();

            CRUDOperations obj2 = new CRUDOperations();
            obj2.AddOperation();

            Console.ReadKey();
        }
    }
}
