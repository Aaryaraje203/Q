﻿// Default code generation is disabled for model 'D:\Vinit Suryarao\Module 3\Sample Entity Framework\LINQ to EF\LINQ to EF WPF\Model2.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.