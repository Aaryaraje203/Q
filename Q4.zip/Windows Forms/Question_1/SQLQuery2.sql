CREATE TABLE ConsumerRegistration_121880
(
	ConsumerName varchar(20),
	ConsumerEmail varchar(20) PRIMARY KEY,
	MobileNumber bigint,
	Address      varchar(20)
)

CREATE TABLE ComplaintDetails_121880
(
	ComplaintID       int IDENTITY(1,1) PRIMARY KEY,
	ConsumerEmail     varchar(20) references ConsumerRegistration_121880(ConsumerEmail),
	Category          varchar(20),
	ProductName		  varchar(20),
	DateOfPurchase    Datetime,
	ProductValue      int,
	DealerDetails     varchar(50),
	City              varchar(20),
	ComplaintDetails  varchar(50),
)

INSERT INTO ConsumerRegistration_121880( ConsumerName, ConsumerEmail, MobileNumber, Address) Values('Vinit Suryarao','vinit@gmail.com',9967566673,'Thane');
INSERT INTO ConsumerRegistration_121880( ConsumerName, ConsumerEmail, MobileNumber, Address) Values('Shubham Agrhwal','shubham@gmail.com',9517566673,'Kalava');
INSERT INTO ConsumerRegistration_121880( ConsumerName, ConsumerEmail, MobileNumber, Address) Values('Karndeep Rana','rana@gmail.com',9978456673,'Mahim');
INSERT INTO ConsumerRegistration_121880( ConsumerName, ConsumerEmail, MobileNumber, Address) Values('Saurabh Dubey','dubey@gmail.com',9987456673,'Vasai');


go
CREATE PROCEDURE SP_RegisterComplaint
(
	@consumerEmail     varchar(20),
	@category          varchar(20),
	@productName		  varchar(20),
	@dateOfPurchase    Datetime,
	@productValue      int,
	@dealerDetails     varchar(50),
	@city              varchar(20),
	@complaintDetails  varchar(50)
)
AS
BEGIN
	INSERT INTO ComplaintDetails_121880 (ConsumerEmail,
										 Category, 
										 ProductName,	
										 DateOfPurchase, 
										 ProductValue,
									     DealerDetails, 
										 City,
										 ComplaintDetails)
	                             values( @consumerEmail,
										 @category, 
										 @productName,	
										 @dateOfPurchase, 
										 @productValue,
									     @dealerDetails, 
										 @city,
										 @complaintDetails);


END

SP_RegisterComplaint 'rana@gmail.com','Domestic','food','02/02/2000',1200,'Sai Shop','Chennai','ttt'

Alter PROCEDURE SP_SearchEmail
(
	@email varchar(20)
)
AS
BEGIN
		select * from ConsumerRegistration_121880 where ConsumerEmail=@email;
END

SP_SearchEmail 'vinit@gmail.com'

