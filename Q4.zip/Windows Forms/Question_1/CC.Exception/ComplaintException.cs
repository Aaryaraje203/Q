﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CC.Exception
{
    /// <summary>
    /// Class               : Exception class for throw user define exception
    /// Employee ID         : 121880
    /// Author              : Vinit Suryarao
    /// Date Modified       : 14th march 2017
    /// Version No          : 1.0
    /// Change Description  : No Change
    /// </summary>
    
    public class ComplaintException:ApplicationException
    {
         public ComplaintException() : base() { }
         public ComplaintException(string message) : base(message) { }
    }
}
