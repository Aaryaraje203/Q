﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CC.BL;
using CC.Entity;
using CC.Exception;
using System.Data.SqlClient;

namespace CC.PL
{
    public partial class Form1 : Form
    {
        ComplaintValidations validationsObj = new ComplaintValidations();
         Complaint complaintObj = new Complaint();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                complaintObj.consumerEmail = txtConsumerEmail.Text;
                bool complaintSearch = validationsObj.SearchRecord(complaintObj);
                if (complaintSearch)
                {
                    groupBox1.Visible = true;
                }
                else
                {
                    MessageBox.Show("You are not registered User !! Please register and raise complaint", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (ComplaintException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

           

            complaintObj.consumerEmail = txtConsumerEmail.Text;
            complaintObj.category = txtCategory.Text;
            complaintObj.productName = txtProductName.Text;
            complaintObj.dateOfPurchase = Convert.ToDateTime(txtDateOfPurchase.Text);
            complaintObj.productValue = Convert.ToInt32(txtProductValue.Text);
            complaintObj.dealerDetails = txtDealerDetails.Text;
            complaintObj.city = txtCity.Text;
            complaintObj.complaintDetails = txtComplaintDetails.Text;

            bool complaintAdded = validationsObj.AddRecord(complaintObj);
            if (complaintAdded)
                    MessageBox.Show("Dear Customer, our executive will get back you", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Complaint not registered", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ComplaintException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
