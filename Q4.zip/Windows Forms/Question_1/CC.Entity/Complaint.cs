﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CC.Entity
{
    /// <summary>
    /// Class               : Entity to store Consumer Complaint Information
    /// Employee ID         : 121880
    /// Author              : Vinit Suryarao
    /// Date Modified       : 14th march 2017
    /// Version No          : 1.0
    /// Change Description  : No Change
    /// </summary>
   
    public class Complaint
    {
        /// <summary>
        /// Property to store and retrieve Consumer Email ID
        /// </summary>
        public string consumerEmail { get; set; }

        /// <summary>
        /// Property to store and retrieve Category
        /// </summary>
        public string category { get; set; }

        /// <summary>
        /// Property to store and retrieve Product Name
        /// </summary>
        public string productName { get; set; }

        /// <summary>
        /// Property to store and retrieve Date of Purchase
        /// </summary>
        public DateTime dateOfPurchase { get; set; }

        /// <summary>
        /// Property to store and retrieve Product Value
        /// </summary>
        public int productValue { get; set; }

        /// <summary>
        /// Property to store and retrieve Dealer Details
        /// </summary>
        public string dealerDetails { get; set; }

        /// <summary>
        /// Property to store and retrieve City
        /// </summary>
        public string city { get; set; }

        /// <summary>
        /// Property to store and retrieve Complaint Details
        /// </summary>
        public string complaintDetails { get; set; }

     
    }
}
