﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CC.Entity;
using CC.Exception;              

namespace CC.DAL
{
    /// <summary>
    /// Class               : class contains the all Consumer Complaint Operations
    /// Employee ID         : 121880
    /// Author              : Vinit Suryarao
    /// Date Modified       : 8th march 2017
    /// Version No          : 1.0
    /// Change Description  : No Change
    /// </summary>
    public class ComplaintOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        public ComplaintOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConsumerComplaint"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method             : Method to search member is registered or not
        /// Author             : Vinit Suryarao
        /// Date Modified      : 8th march 2017
        /// Version No         : 1.0
        /// Change Description : No Change
        /// </summary>
        /// <param name="complaintObj"></param>
        /// <returns>bool</returns>

        public bool SearchRecord(Complaint complaintObj)
        {
            try
            {
              
                bool complaintSearch = false;
               
                SqlCommand cmdSearch = new SqlCommand("SP_SearchEmail", connection);
                cmdSearch.CommandType = CommandType.StoredProcedure;
                cmdSearch.Parameters.AddWithValue("@email", complaintObj.consumerEmail);
                connection.Open();
                reader = cmdSearch.ExecuteReader();

                //int result = cmdSearch.ExecuteNonQuery();

                if (reader != null)
                {
                    complaintSearch = true;
                }
                    return complaintSearch;
            }
            catch (ComplaintException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Method             : Method to add complaint record
        /// Author             : Vinit Suryarao
        /// Date Modified      : 8th march 2017
        /// Version No         : 1.0
        /// Change Description : No Change
        /// </summary>
        /// <param name="complaintObj"></param>
        /// <returns>bool</returns>
        
        public bool AddRecord(Complaint complaintObj)
        {
            try
            {
                bool complaintSearch = false;
                SqlCommand cmdAdd = new SqlCommand("SP_RegisterComplaint", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@consumerEmail", complaintObj.consumerEmail);
                cmdAdd.Parameters.AddWithValue("@category", complaintObj.category);
                cmdAdd.Parameters.AddWithValue("@productName", complaintObj.productName);
                cmdAdd.Parameters.AddWithValue("@dateOfPurchase", complaintObj.dateOfPurchase);
                cmdAdd.Parameters.AddWithValue("@productValue", complaintObj.productValue);
                cmdAdd.Parameters.AddWithValue("@dealerDetails", complaintObj.dealerDetails);
                cmdAdd.Parameters.AddWithValue("@city", complaintObj.city);
                cmdAdd.Parameters.AddWithValue("@complaintDetails", complaintObj.complaintDetails);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    complaintSearch = true;
                return complaintSearch;
            }
            catch (ComplaintException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }


    }
}
