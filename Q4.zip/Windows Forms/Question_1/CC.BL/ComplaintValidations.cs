﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using CC.Entity;
using CC.Exception;
using CC.DAL;

namespace CC.BL
{
    /// <summary>
    /// Class               : class contains the all validations and logic
    /// Employee ID         : 121880
    /// Author              : Vinit Suryarao
    /// Date Modified       : 14th march 2017
    /// Version No          : 1.0
    /// Change Description  : No Change
    /// </summary>
    
    public class ComplaintValidations
    {
        ComplaintOperations operationObj = new ComplaintOperations();

        /// <summary>
        /// Method              : Method to validate member record
        /// Author              : Vinit Suryarao
        /// Date Modified       : 8th march 2017
        /// Version No          : 1.0
        /// Change Description  : No Change
        /// </summary>
        /// <param name="Obj"></param>
        /// <returns></returns>

        public bool ValidateEmail(Complaint complaintObj)
        {
            bool validComplaint = true;
            StringBuilder sb = new StringBuilder();

            if (complaintObj.consumerEmail.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Consumer Email ID Should Not Be Blank, Please Enter Consumer Email ID ");
            }
            if (validComplaint == false)
                throw new ComplaintException(sb.ToString());
            return validComplaint;
        }

       public bool ValidateComplaint(Complaint complaintObj)
        {
            bool validComplaint = true;
            StringBuilder sb = new StringBuilder();

            if (complaintObj.consumerEmail.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Consumer Email ID Should Not Be Blank, Please Enter Consumer Email ID ");
            }
            if (complaintObj.category.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Category Should Be Blank, Please Enter Category ");
            }
            if (!(Regex.IsMatch(complaintObj.category, @"^[a-zA-Z ]+$")))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Category should contain only characters.");
            }
            if (complaintObj.category.ToLower() != "domestic" && complaintObj.category.ToLower() != "commercial" && complaintObj.category.ToLower() != "educational" && complaintObj.category.ToLower() != "medicine" && complaintObj.category.ToLower() != "others")
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Category should be Domestic,Commercial,Educational,Medicine,Others");
            }
            if (complaintObj.productName.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product Name Should Not Be Blank, Please Enter Product Name ");
            }
            if (!(Regex.IsMatch(complaintObj.productName, @"^[a-zA-Z ]+$")))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product Name should contain only characters.");
            }
            if (complaintObj.dateOfPurchase == null)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Date OF Purchase Should Not Blank, Please Enter Date Of Purchase ");
            }
            if (Convert.ToDateTime(complaintObj.dateOfPurchase) > Convert.ToDateTime(DateTime.Today))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Date of purchase should be less than current date ");
            }
            if (complaintObj.productValue==null)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Product Value Should Not Blank, Please Enter Product Value ");
            }
            if (complaintObj.dealerDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Dealer Details Should Not Blank, Please Enter Dealer Details ");
            }
            if (!(Regex.IsMatch(complaintObj.dealerDetails, @"^[a-zA-Z ]+$")))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Dealer Details should contain only characters.");
            }
            if (complaintObj.city.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "City Should Not Blank, Please Enter City ");
            }
            if (!(Regex.IsMatch(complaintObj.city, @"^[a-zA-Z ]+$")))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "City should contain only characters.");
            }
            if (complaintObj.complaintDetails.Length == 0)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaint Details Should Not Blank, Please Enter Complaint Details ");
            }
            if (!(Regex.IsMatch(complaintObj.complaintDetails, @"^[a-zA-Z ]+$")))
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaint Details should contain only characters.");
            }
            if (complaintObj.complaintDetails.Length > 200)
            {
                validComplaint = false;
                sb.Append(Environment.NewLine + "Complaints Details should be less than 200 characters");
            }
            if (validComplaint == false)
                throw new ComplaintException(sb.ToString());
            return validComplaint;

        }
        /// <summary>
        /// Method              : Method to call method for search record
        /// Author              : Vinit Suryarao
        /// Date Modified       : 14th march 2017
        /// Version No          : 1.0
        /// Change Description  : No Change
        /// </summary>
        /// <param name="complaintObj"></param>
        /// <returns>bool</returns>
        /// 
        public bool SearchRecord(Complaint complaintObj)
        {
            bool complaintSearch = false;
            if (ValidateEmail(complaintObj))
                complaintSearch = operationObj.SearchRecord(complaintObj);
            return complaintSearch;
        }

        /// <summary>
        /// Method              : Method to call method for add record
        /// Author              : Vinit Suryarao
        /// Date Modified       : 14th march 2017
        /// Version No          : 1.0
        /// Change Description  : No Change
        /// </summary>
        /// <param name="complaintObj"></param>
        /// <returns>bool</returns>
        /// 
        public bool AddRecord(Complaint complaintObj)
        {
            bool complaintAdded = false;
            if (ValidateComplaint(complaintObj))
                complaintAdded = operationObj.AddRecord(complaintObj);
            return complaintAdded;
        }
    }
}
