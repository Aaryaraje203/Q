function showFunction1()
		{
		alert("Your name Is :-"+ form1.name.value + "\nYour Email Is :-"+ form1.email.value + "\nYour Phone Is :-"+ form1.phone.value);
		
		}
		
		function showFunction2()
		{
			var name=form2.name2.value;
			var email=form2.email2.value;
			var phone=form2.phone2.value;
			if(name=="")
			{
				alert("Your Name Should Not Be Blank");
				form2.name2.focus();
				
			}
			else if( email=="")
					{
						//document.write("<h1> Email Should Not Blank</h1>");
						alert("Your Email Should Not Be Blank");
						form2.email2.focus();
						
					}
			else if(phone=="")
					{	
						//window.open("FirstForm.html");
						alert("Your Phone Should Not Be Blank");
						form2.phone2.focus();
						
					}
		
		}