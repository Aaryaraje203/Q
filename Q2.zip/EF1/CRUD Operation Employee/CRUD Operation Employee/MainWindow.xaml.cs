﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CRUD_Operation_Employee
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            EmployeeContext context = new EmployeeContext();
            Employee e1 = new Employee()
            {
                ID=int.Parse(txtID.Text),
                Name=txtName.Text,
                DOB=Convert.ToDateTime(txtDOB.Text),
                DOJ=Convert.ToDateTime(txtDOJ.Text),
                Designation=txtDesignation.Text,
                Salary=Convert.ToDecimal(txtSalary.Text)
            };

            try
            {
                context.Employees.Add(e1);
                context.SaveChanges();
                MessageBox.Show("Record is Added Succesfully");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            EmployeeContext context = new EmployeeContext();
            Employee eee = new Employee();
            int x = Convert.ToInt32(txtID.Text);
            Employee empupd = (from s in context.Employees.Where(s => s.ID == x)
                               select s).FirstOrDefault();

            if (empupd != null)
            {
                empupd.ID = int.Parse(txtID.Text);
                empupd.Name = txtName.Text;
                empupd.DOB = Convert.ToDateTime(txtDOB.Text);
                empupd.DOJ = Convert.ToDateTime(txtDOJ.Text);
                empupd.Designation = txtDesignation.Text;
                empupd.Salary = Convert.ToDecimal(txtSalary.Text);
                context.SaveChanges();
                MessageBox.Show("Record is Updated Succesfully");
            }
            else
            {
                MessageBox.Show("Record is Not Updated Succesfully");
            }
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            EmployeeContext context = new EmployeeContext();
            var query = from e4 in context.Employees
                        select e4;
            DataGrid1.ItemsSource = query.ToList();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            EmployeeContext context = new EmployeeContext();
            Employee eee = new Employee();

            var query2 = from e5 in context.Employees
                       where (e5.ID).ToString() == txtID.Text
                        select e5;
            DataGrid1.ItemsSource = query2.ToList();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            EmployeeContext context=new EmployeeContext();

             int x = Convert.ToInt32(txtID.Text);
            Employee empdel=(from s in context.Employees.Where(s=> s.ID== x)
                             select s).FirstOrDefault();

            if (empdel != null)
            {
                context.Employees.Remove(empdel);
                context.SaveChanges();
                MessageBox.Show("Record is Deleted Successfully");
            }
            else
            {
                MessageBox.Show("Record Not Found");
            }
        }
    }
}
