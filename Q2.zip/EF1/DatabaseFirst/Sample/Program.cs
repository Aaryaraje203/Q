﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_18Jan2017_TalwadeEntities1 en = new Training_18Jan2017_TalwadeEntities1();

            //var query = from e in en.Albums
            //            select e;
            //try
            //{
            //    foreach (var item in query)
            //    {
            //        Console.WriteLine(item.AlbumID + item.Name + item.CreationYear + item.Genre + item.Price);
            //    }
            //}
            //catch (SystemException ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}

            Album obj=new Album()
            {
                AlbumID=989,
                Name="Rana",
                Genre="Raanvata",
                CreationYear=Convert.ToDateTime("12/5/2016"),
                Price=100
        };
            en.Albums.Add(obj);
            en.SaveChanges();
            Console.WriteLine("Data Added Successfully");
            Console.ReadLine();

        }
    }
}
