﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext pcontext = new ProductContext();
            Product p1 = new Product() { ProductID=121, Name="Vinit",Category="Man",Price=199 };
            Product p2 = new Product() { ProductID = 122, Name = "Dubey", Category = "Other", Price = 10 };

            try
            {

                pcontext.Products.Add(p1);
                pcontext.Products.Add(p2);
                pcontext.SaveChanges();

                Console.WriteLine("Products Data Added Successfully");
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
                Console.ReadKey();
        }
    }
}
