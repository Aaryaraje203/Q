-------------------------------------------------------------------------------------------------------------------------------
--                                                Lab 1 Assignment
--                               Assignment 1.6 :- Indexes and Views
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
--1) Create a Unique index on Department Name for Department master Table ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE UNIQUE NONCLUSTERED INDEX Indx_DepttName_121880
On University_121880.Department_Master(Dept_name);

-------------------------------------------------------------------------------------------------------------------------------
2) Try inserting the following values and observe the output
--Dept Code		 Dept Name
--100				Home Science
--200				Home Science
--300				NULL
--400				NULL
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

INSERT INTO University_121880.Department_Master ( Dept_Code, Dept_Name ) Values(100, 'Home Science');
INSERT INTO University_121880.Department_Master ( Dept_Code, Dept_Name ) Values(200, 'Home Science');
INSERT INTO University_121880.Department_Master ( Dept_Code, Dept_Name ) Values(300, NULL);
INSERT INTO University_121880.Department_Master ( Dept_Code, Dept_Name ) Values(400, NULL);


-------------------------------------------------------------------------------------------------------------------------------
--3) Create a non-clustered index for Book_Trans table on the following columns
--Book_code, Staff_name, student name, date of issue. Try adding some values.
--Do you experience any difficulties?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE NONCLUSTERED INDEX University_121880_Indx_Book_Code
ON University_121880.Book_Transaction(Book_Code);

CREATE NONCLUSTERED INDEX University_121880_Indx_Issue_Date
ON University_121880.Book_Transaction(Issue_Date);

CREATE NONCLUSTERED INDEX University_121880_Indx_Satff_Name
ON University_121880.Staff_Master(Staff_Name);

CREATE NONCLUSTERED INDEX University_121880_Indx_Satff_Name
ON University_121880.Student_Master(Stud_Name);


-------------------------------------------------------------------------------------------------------------------------------
--4) List the indexes created in the previous questions, from the sysindexes table ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

EXEC sysindex 'University_121880_Indx_Book_Code'
EXEC sysindex 'University_121880_Indx_Issue_Date'
EXEC sysindex 'University_121880_Indx_Satff_Name'
EXEC sysindex 'University_121880_Indx_Satff_Name'


-------------------------------------------------------------------------------------------------------------------------------
--5) Create a View with the name StaffDetails_view with the following column name 
--Staff Code, Staff Name, Department Name, Desig Name salary
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE VIEW [University_121880].[StaffDetails_View]
WITH ENCRYPTION
AS
SELECT SM.Staff_Code, SM.Staff_Name, DM.Dept_Name, DG.Design_Name
FROM University_121880.Staff_Master SM
INNER JOIN University_121880.Department_Master DM
ON SM.Dept_Code=DM.Dept_Code
INNER JOIN University_121880.Desig_Master DG
ON SM.Des_Code=DG.Design_Code;

SELECT * FROM [University_121880].[StaffDetails_View];

-------------------------------------------------------------------------------------------------------------------------------
--9) Try inserting some records in the view; Are you able to add records? Why not? Write your answers here.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

INSERT INTO StaffNameView 
VALUES ('Raju');

-------------------------------------------------------------------------------------------------------------------------------
--8) View the definition of the view using the following syntax. 
--Sp_helptext <viewname>
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

EXEC sp_helptext StaffDetails_View

-------------------------------------------------------------------------------------------------------------------------------
--9) Using the view , List out all the staffs who have joined in the month of June
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

select * from University_121880.staff_master;

CREATE VIEW StaffNameView
AS
SELECT Staff_Name
FROM University_121880.Staff_Master
WHERE DATENAME(month,hiredate)='June';

SELECT * FROM StaffNameView;

---------------------------------------------------------------------------------------------------------------------------------
--10) Create a non-clustered column store index on EmployeeID of Employees table
---------------------------------------------------------------------------------------------------------------------------------

CREATE NONCLUSTERED COLUMNSTORE INDEX IndxEmpID
ON dbo.Employees_121880(EmployeeId);

