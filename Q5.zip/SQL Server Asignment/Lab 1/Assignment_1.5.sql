-------------------------------------------------------------------------------------------------------------------------------
--                                                Lab 1 Assignment
--                               Assignment 1.5 :- Data Retrieval - Joins, Subqueries, SET Operators and DML
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
--1) Write a query which displays Staff Name, Department Code, Department Name, 
--and Salary for all staff who earns more than 20000.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT StaffTable.Staff_Name, StaffTable.Dept_Code, DeptTable.Dept_Name, StaffTable.Salary
FROM University_121880.Staff_Master StaffTable
INNER JOIN University_121880.Department_Master DeptTable
On StaffTable.Dept_Code=DeptTable.Dept_Code;



-------------------------------------------------------------------------------------------------------------------------------
--2) Write a query to display Staff Name, Department Code, and Department Name for all 
-- staff who do not work in Department code 10 ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT StaffTable.Staff_Name, StaffTable.Dept_Code, DeptTable.Dept_Name
FROM University_121880.Staff_Master StaffTable
INNER JOIN University_121880.Department_Master DeptTable
On StaffTable.Dept_Code=DeptTable.Dept_Code AND StaffTable.Dept_Code <> 10;



-------------------------------------------------------------------------------------------------------------------------------
--3) Print out a report like this 
--		Book Name		No of times issued
--		Let us C			12
--		Linux Internals		 9
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT BookMaster.Book_Name, COUNT( BookTran.Issue_date) [No of times issued]
FROM University_121880.Book_Master BookMaster
INNER JOIN University_121880.Book_Transaction BookTran
ON BookMaster.Book_Code=BookTran.Book_Code
GROUP BY BookMaster.Book_Name;
 


-------------------------------------------------------------------------------------------------------------------------------
--4) List out number of students joined each department last year. The report should be displayed like this
--		Physics		12
--		Chemistry	40
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT DeptMaster.Dept_Name, COUNT(StudMaster.Stud_Code) [ No of student ]
FROM University_121880.Student_Master StudMaster
INNER JOIN University_121880.Department_Master DeptMaster
ON DeptMaster.Dept_Code=StudMaster.Dept_Code AND StudMaster.Stud_Code IN( SELECT Stud_Code
																		 FROM University_121880.Student_Marks
																		 WHERE Stud_Year= YEAR(GETDATE())-10
																		)
GROUP BY DeptMaster.Dept_Name;

-------------------------------------------------------------------------------------------------------------------------------
--5) List out a report like this Staff Code Staff Name Manager Code Manager Name
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT StaffMaster1.Staff_Code [Staff Code] , StaffMaster1.Staff_Name [Staff Name], StaffMaster2.Mgr_Code [Manager Code], StaffMaster2.Staff_Name [Manager Name]
FROM University_121880.Staff_Master StaffMaster1
INNER JOIN University_121880.Staff_Master StaffMaster2
ON StaffMaster1.Staff_Code=StaffMaster2.Mgr_Code;



-------------------------------------------------------------------------------------------------------------------------------
--6) Display the Staff Name, Hire date and day of the week on which staff was hired. 
--Label the column as DAY. Order the result by the day of the week starting with Monday.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT Staff_Name, Hiredate, DATENAME(dw,Hiredate) AS Day
FROM University_121880.Staff_Master
ORDER BY Day;



-------------------------------------------------------------------------------------------------------------------------------
--8) List out the names of all student code whose score in subject1 is equal to the highest score
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-


SELECT SMS.Stud_Name
FROM University_121880.Student_Marks SMR
INNER JOIN University_121880.Student_Master SMS
ON SMR.Stud_Code=SMS.Stud_Code
WHERE SMR.Subject1 = ( SELECT MAX(Subject1)
					   FROM University_121880.Student_Marks)


-------------------------------------------------------------------------------------------------------------------------------
--9) Modify the above query to display student names along with the codes.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT SMR.Stud_Code,SMS.Stud_Name
FROM University_121880.Student_Marks SMR
INNER JOIN University_121880.Student_Master SMS
ON SMR.Stud_Code=SMS.Stud_Code
WHERE SMR.Subject1 = ( SELECT MAX(Subject1)
					   FROM University_121880.Student_Marks)


-------------------------------------------------------------------------------------------------------------------------------
--11) List out the names of all the books along with the author name, book code and 11.category which 
--have not been issued at all. Try solving this question using EXISTS.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT Author, Book_Code
FROM University_121880.Book_Master
WHERE EXISTS
( SELECT Book_Code
  FROM University_121880.Book_Transaction
  WHERE Issue_date IS NULL
)
-------------------------------------------------------------------------------------------------------------------------------
--12) List out the code and names of all staff and students belonging to department ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT Staff_Code Codes, Staff_Name Names
FROM University_121880.Staff_Master
Where Dept_Code = 20
UNION
SELECT Stud_Code, Stud_Name
FROM University_121880.Student_Master
Where Dept_Code=20;

-------------------------------------------------------------------------------------------------------------------------------
--13)List out all the students who have not appeared for exams this year.  
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT * FROM University_121880.Student_Marks SMR
INNER JOIN University_121880.Student_Master SMS
ON SMR.Stud_Code=SMS.Stud_Code
WHERE SMR.Subject1 IS NULL AND SMR.Subject2 IS NULL AND SMR.Subject3 IS NULL;

-------------------------------------------------------------------------------------------------------------------------------
--14) List out all the student codes who have never taken books
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT Stud_Code 
FROM University_121880.Student_Master
EXCEPT
SELECT Stud_Code
FROM University_121880.Book_Transaction;

-------------------------------------------------------------------------------------------------------------------------------
--15) Add the following records to the Customers Table , created in our earlier exercises ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

EXEC SP_HELP Customer_121880
EXEC SP_HELP Order_121880

DROP TABLE Customer_121880

ALTER TABLE Customer_121880
DROP CONSTRAINT UQ__Customer__A4AD58915D883E16

ALTER TABLE Orders_121880
DROP CONSTRAINT fk_CustOrders_121880

DROP INDEX University_121880.UQ__Customer__A4AD58915D883E16

ALTER TABLE Customer_121880
ALTER COLUMN CustomerId Varchar(40)

ALTER TABLE Customer_121880
ALTER COLUMN CustomerName Varchar(40)

ALTER TABLE Customer_121880
ALTER COLUMN ContactNumber Varchar(40)

ALTER TABLE Customer_121880
ALTER COLUMN PostalCode Varchar(40)


INSERT INTO Customer_121880 VALUES ('ALFKI','AlfredsFutterKiste','ObereStr 57','Berlin,Germany',030-0074321,12209,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('ANATR','Ana Trujillo Emparedados y helados','Avda. de la Constituci�n 2222','M�xico D.F.,Mexico',555-4729,5021,'NA',NULL);
INSERT INTO Customer_121880 VALUES ('ANTON','Antonio Moreno Taquer�a','Mataderos 2312','M�xico D.F.,Mexico',555-3932,5023,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('AROUT','Around the Horn','120 Hanover Sq.','London,UK',555-7788,WA1 1DP,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('BERGS','Berglundssnabbk�p','Berguvsv�gen 8','Lule�,Sweden',0921-12 34 65,S-958 22,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('BLAUS','Blauer See Delikatessen','Forsterstr. 57','Mannheim,Germany',0621-08460,NA,NULL);
INSERT INTO Customer_121880 VALUES ('BOLID','B�lidoComidaspreparadas','C/ Araquil, 67','Madrid,Spain',555 22 82,28023,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('BONAP','Bon app','12, rue des Bouchers','Marseille,France',91.24.45.40,13008,NULL,NULL);
INSERT INTO Customer_121880 VALUES ('BOTTM','Bottom-Dollar Markets','23 Tsawassen Blvd.','Tsawassen,Canada',555-4729,T2F 8M4,BC);


-------------------------------------------------------------------------------------------------------------------------------
--16) Replace the contact number of Customer id ANATR to (604) 3332345. ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

UPDATE Customer_121880
SET ContactNumber='(604)3332345'
WHERE CustomerId='ANTR'

-------------------------------------------------------------------------------------------------------------------------------
--17) Update the Address and Region of Customer BOTTM to the following
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

UPDATE Customer_121880
SET Address1='19/2 12th Block, Spring Fields', Address2='Ireland - UK', Region='EU'
WHERE CustomerId='BOTTM';

-------------------------------------------------------------------------------------------------------------------------------
--18) Insert the following records in the Orders table. The Order id should be automatically generated
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

EXEC SP_HELP Orders_121880
SELECT * FROM Orders_121880

ALTER TABLE Order_121880
ALTER COLUMN CustomerID varchar(40)

INSERT INTO Orders_121880 VALUES ('AROUT','4-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('ALFKI','5-Jul-96','C')
INSERT INTO Orders_121880 VALUES ('BLONP','8-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('ANTON','8-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('ANTON','9-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('BOTTM','10-Jul-96','C')
INSERT INTO Orders_121880 VALUES ('BONAP','11-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('ANATR','12-Jul-96','P')
INSERT INTO Orders_121880 VALUES ('BALUS','15-Jul-96','C')
INSERT INTO Orders_121880 VALUES ('HILLA','16-Jul-96','P')

-------------------------------------------------------------------------------------------------------------------------------
--19) Delete all the Customers whose Orders have been cleared
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-


DELETE Orders_121880
WHERE Order_State='C'

-------------------------------------------------------------------------------------------------------------------------------
--20) Remove all the records from the table using the truncate command. Rerun the script 20.to populate the records once again
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

TRUNCATE TABLE Orders_121880

-------------------------------------------------------------------------------------------------------------------------------
--21) Change the order status to C, for all orders before `15th July?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

UPDATE Orders_121880
SET Order_State='C'
WHERE OrdersDate='15 Jully'



































-------------------------------------------------------------------------------------------------------------------------------
--
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-
