
-- Creating View on Single table

CREATE VIEW University_121880.StaffDateINfo
WITH ENCRYPTION
AS
	SELECT Staff_Code, Staff_Name, Staff_Dob, Hiredate
	FROM University_121880.Staff_master;

SELECT * FROM University_121880.StaffDateINfo;


-- Creating View on Multiple tables

CREATE VIEW University_121880.StaffDeptInfo
WITH ENCRYPTION
As
	SELECT St.Staff_Code, St.Staff_Name, Dp.Dept_Name
	FROM University_121880.Staff_master St
	INNER JOIN University_121880.Department_master Dp
	ON St.Dept_Code=Dp.Dept_Code;
	
SELECT * FROM University_121880.StaffDeptInfo;


-- Create Clustered Index

CREATE UNIQUE CLUSTERED INDEX IndxPostal
ON Customer(PostalCode);

SELECT * FROM IndxPostal;

-- Create NonClustered Index

CREATE NONCLUSTERED INDEX Index_Book_121880
ON University_121880.Book_Master(Book_Name);

SELECT * FROM University_121880.Book_Master;


-- Join

SELECT BookMaster.Book_Name, COUNT( BookTran.Issue_date) [No of times issued]
FROM University_121880.Book_Master BookMaster
INNER JOIN University_121880.Book_Transaction BookTran
ON BookMaster.Book_Code=BookTran.Book_Code
GROUP BY BookMaster.Book_Name;


-- Creating Simple Stored Procedure

CREATE PROCEDURE University_121880.SatffDateInfo
AS
BEGIN
	SELECT  Staff_Code, Staff_Name, Staff_Dob, Hiredate, Address 
	FROM University_121880.staff_master
END

EXEC University_121880.SatffDateInfo



EXEC sp_addmessage 50056,1,'Invalid Book Id'

ALTER PROCEDURE ProcUpdateSalary 
 (
	@Staff_Code int,
	@Salary int OUT
 )
 AS
 BEGIN   
        BEGIN TRY
	    DECLARE @Staff_Exp int
		SELECT @Staff_Exp=(YEAR(GETDATE())-YEAR(Hiredate))
		FROM University_121880.Staff_Master
		WHERE Staff_Code=@Staff_Code;

		UPDATE University_121880.Staff_Master_Back
		SET OldSalary=( SELECT Salary 
						FROM University_121880.Staff_Master
						WHERE Staff_Code=@Staff_Code)
		WHERE Staff_Code=@Staff_Code;
					
		IF @Staff_Exp >= 2 AND @Staff_Exp <= 5
			BEGIN
			UPDATE University_121880.Staff_Master
			SET Salary=0.20*Salary+Salary
			WHERE Staff_Code=@Staff_Code;
			RETURN @Salary
			END
		
		IF @Staff_Exp > 5  
			BEGIN
			UPDATE University_121880.Staff_Master
			SET Salary=0.25*Salary+Salary
			WHERE Staff_Code=@Staff_Code;
			RETURN @Salary
			END
		END TRY
		BEGIN CATCH
			RAISERROR(50001,1,1)
			ROLLBACK TRAN
		END CATCH
	
 END

 DECLARE @Salary int ;
 EXEC ProcUpdateSalary 100002, @Salary OUT;