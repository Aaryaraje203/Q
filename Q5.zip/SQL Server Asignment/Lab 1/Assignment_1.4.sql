-------------------------------------------------------------------------------------------------------------------------------
--                                                Lab 1 Assignment
--                               Assignment 1.4 :- Simple Queries & Merge Statement
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
--For these questions, you will be using the University Schema; the table structure has been given in the appendix. 
--These tables would be available in the Training database
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE SCHEMA University_121880
Go

-------------------------------------------------------------------------------------------------------------------------------
--1) List out Student_Code, Student_Name and Department_Code of every Student ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution:-

SELECT Stud_Code, Stud_Name, Dept_Code
FROM University_121880.Student_master;

-------------------------------------------------------------------------------------------------------------------------------
--2) Do the same for all the staff�s ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Staff_Code, Staff_Name, Dept_Code
FROM University_121880.Staff_Master;

-------------------------------------------------------------------------------------------------------------------------------
--3) Retrieve the details (Name, Salary and dept code) of the employees who are working in department 20, 30 and 40 ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution:-

SELECT Staff_Name, Salary, Dept_Code
FROM University_121880.Staff_Master
WHERE Dept_Code IN( 20,30,40 );

-------------------------------------------------------------------------------------------------------------------------------
--4) Display Student_Code, Subjects and Total_Marks for every student. Total_Marks will calculate as 
--Subject1 + Subject2 + Subject3 from University_121880.Student_Marks. The records should be displayed in the
-- descending order of Total Score ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Stud_Code, ISNULL(Subject1,0) Subject1, ISNULL(Subject2,0) Subject2, ISNULL(Subject3,0)Subject3, ISNULL(Subject1 + Subject2 + Subject3, 0) Total_Marks
FROM University_121880.Student_Marks
ORDER BY Total_Marks DESC;

-------------------------------------------------------------------------------------------------------------------------------
--5) List out all the books which starts with �An�, along with price ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Book_Name
FROM University_121880.Book_Master
WHERE Book_Name LIKE 'An%';

-------------------------------------------------------------------------------------------------------------------------------
--6) List out all the department codes in which students have joined this year ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Dept_Code
FROM University_121880.Student_Master
WHERE Stud_Code IN ( SELECT Stud_Code 
					 FROM University_121880.Student_Marks
					 WHERE Stud_Year = year(getdate())
				   );

-------------------------------------------------------------------------------------------------------------------------------
--7) Display name and date of birth of students where date of birth must be displayed in the format similar 
--to �January, 12 1981� for those who were born on Saturday or Sunday ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Stud_Name, CONVERT(varchar(11), Stud_Dob,109) DateOfBirth
FROM University_121880.Student_Master
WHERE DATENAME(dw, Stud_Dob) IN ( 'Saturday','Sunday');

-------------------------------------------------------------------------------------------------------------------------------
--8)List out a report like this 
--StaffCode StaffName Dept Code Date of Joining No of years in the Company ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution:-

SELECT Staff_Code, Staff_Name, Dept_Code, Hiredate [ Date Of Joining ], YEAR(GETDATE())-YEAR( Hiredate) [No Of Years In Company]
FROM University_121880.Staff_Master;

-------------------------------------------------------------------------------------------------------------------------------
--9) List out all staffs who have joined before Jan 2000 ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT * FROM University_121880.Staff_Master
WHERE DATENAME(YEAR, Hiredate) < 2000;
 
-------------------------------------------------------------------------------------------------------------------------------
--10) Write a query which will display Student_Name, Departmnet_Code and DOB of all students 
--who born between January 1, 1981 and March 31, 1983.
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Stud_Code, Stud_Name, Dept_Code, Stud_Dob
FROM University_121880.Student_Master
WHERE Stud_Dob BETWEEN 1/1/1981 AND 31/3/1983;

-------------------------------------------------------------------------------------------------------------------------------
--11) List out all student codes who did not appear in the exam subject2 ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT Stud_Code
FROM University_121880.Student_Marks
WHERE Subject2 IS NULL;

