-------------------------------------------------------------------------------------------------------------------------------
--                                                Lab 1 Assignment
--                               Assignment 1.7 :- Procedures and Exception Handling in SQL server
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
--1) Write a procedure that accept Staff_Code and updates the salary and store the old
--salary details in Staff_Master_Back (Staff_Master_Back has the same structure
--without any constraint) table. The procedure should return the updated salary as the
--return value
--Exp< 2 then no Update
--Exp>= 2 and <= 5 then 20% of salary
--Exp> 5 then 25% of salary
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-


ALTER PROCEDURE ProcUpdateSalary 
 (
	@Staff_Code int,
	@Salary int OUT
 )
 AS
 BEGIN   
        BEGIN TRY
	    DECLARE @Staff_Exp int
		SELECT @Staff_Exp=(YEAR(GETDATE())-YEAR(Hiredate))
		FROM University_121880.Staff_Master
		WHERE Staff_Code=@Staff_Code;

		UPDATE University_121880.Staff_Master_Back
		SET OldSalary=( SELECT Salary 
						FROM University_121880.Staff_Master
						WHERE Staff_Code=@Staff_Code)
		WHERE Staff_Code=@Staff_Code;
					
		IF @Staff_Exp >= 2 AND @Staff_Exp <= 5
			BEGIN
			UPDATE University_121880.Staff_Master
			SET Salary=0.20*Salary+Salary
			WHERE Staff_Code=@Staff_Code;
			RETURN @Salary
			END
		
		IF @Staff_Exp > 5  
			BEGIN
			UPDATE University_121880.Staff_Master
			SET Salary=0.25*Salary+Salary
			WHERE Staff_Code=@Staff_Code;
			RETURN @Salary
			END
		END TRY
		BEGIN CATCH
			RAISERROR(50001,1,1)
			ROLLBACK TRAN
		END CATCH
	
 END

 DECLARE @Salary int ;
 EXEC ProcUpdateSalary 100002, @Salary OUT;


-------------------------------------------------------------------------------------------------------------------------------
--2) Write a procedure to insert details into Book_Transaction table. Procedure should
--accept the book code and staff/student code. Date of issue is current date and the
--expected return date should be 10 days from the current date. If the expected return
--date falls on Saturday or Sunday, then it should be the next working day. Suitable
--exceptions should be handled.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

Select * from student_master;
Select * from university_121880.book_transaction;
Select * from book_master;

ALTER PROCEDURE GetBookDateInfo
(
	@Book_Code int,
	@Code int
)
AS
BEGIN
		
		IF @Book_Code IS NULL OR	@Book_Code<0
			PRINT 'Invalid Book Code'

		IF @Code IS NULL OR	@Code<0
			PRINT 'Invalid Student or Staff Code'
		
        BEGIN TRY
		 IF(DATENAME(dw,GetDate()+10)IN ('Saturday'))
			BEGIN
			UPDATE University_121880.Book_transaction
			SET Exp_Return_Date=GETDATE()+12
			WHERE Book_Code=@Book_Code AND Stud_Code=@Code OR Staff_Code=@Code;
			END

		IF(DATENAME(dw,GetDate()+10)IN ('Sunday'))
			BEGIN
			UPDATE University_121880.Book_transaction
			SET Exp_Return_Date=GETDATE()+11
			WHERE Book_Code=@Code AND Stud_Code=@Code OR Staff_Code=@Code;
			END

		IF(DATENAME(dw,GetDate()+10) NOT IN ('Saturday','Sunday'))
			BEGIN
			UPDATE University_121880.Book_transaction
			SET Exp_Return_Date=GETDATE()+10
			WHERE Book_Code=@Code AND Stud_Code=@Code OR Staff_Code=@Code;
			END
		END TRY
		
		BEGIN CATCH
			RAISERROR(50001,2,2)
			PRINT 'Invalid Data'
			ROLLBACK TRAN
		END CATCH
					
END

EXEC GetBookDateInfo NULL,1002

-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--Solution :-
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--Solution :-
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--Solution :-
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--Solution :-
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--Solution :-