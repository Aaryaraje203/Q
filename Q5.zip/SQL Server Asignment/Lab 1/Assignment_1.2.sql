-------------------------------------------------------------------------------------------------------------------------------
--                                                Lab 1 Assignment
--                                   Assignment 1.2 :-Getting Familiar with SQL Server
-------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------
--1) Identify all the system and user defined database in your system ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :- List of system defined databases are as follows :-
--			1) master
--			2) model
--			3) msdb
--			4) tempdb

--			List of user defined databases are as follows :-
--			1) Training_18Jan2017_Talwade
--			2) Training_25thFeb2016_CGKP
--			3) Training_14Nov2016_Hinjawadi

-------------------------------------------------------------------------------------------------------------------------------
--2) Make master database as your current database , by using the command ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

USE master
go

-------------------------------------------------------------------------------------------------------------------------------
--3) Find out if your active database is master ,by giving the command ?
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

SELECT DB_NAME()
go

-------------------------------------------------------------------------------------------------------------------------------
--4) Now make Training database as your active database ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

USE Training_18Jan2017_Talwade
go

-------------------------------------------------------------------------------------------------------------------------------
--5) Find out the content of the database by giving the following command. Observe the
--output ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

sp_help
go

-------------------------------------------------------------------------------------------------------------------------------
--6) Repeat the above steps for master database and Northwind database :
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

-- For master database
USE master
go

SELECT DB_NAME()
go

sp_help
go

-- For Northwind databse

USE Northwind
go

SELECT DB_NAME()
go

sp_help
go

-------------------------------------------------------------------------------------------------------------------------------
--7) Find out the version of your SQL Server by giving the following command ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

SELECT @@version
go

-------------------------------------------------------------------------------------------------------------------------------
--8) Find out the server date by giving the following commands ?
-------------------------------------------------------------------------------------------------------------------------------
--SOlution :-

SELECT getdate()
go

-------------------------------------------------------------------------------------------------------------------------------
--9) Make Training_18Jan2017_Talwade as your current database , find out information about tables using
--the command - Categories ,Products , Orders, Order Details , Employees ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

USE Northwind
go

sp_help Categories
go

sp_help Products
go

sp_help Orders
go

sp_help OrderDetails
go

sp_help Employees
go

-------------------------------------------------------------------------------------------------------------------------------
--10) Make a note of all related tables and foreign key columns
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

-- Categories table is related to Products.
-- CategoryId, CategoryName of Categories Table is reference by to Product table using CategoryId.
-- Products table is related to OrderDetail and ProductSales.
-- Orders Table Primary Key ( ProductId)
-- ProductId of Orders table reference by to OrderDetails, ProductSales
-- OrderID of OrderDetails table is references to Orders.
-- ProductId of OrderDetails table is references to Products.
-- Employees Table Primary Key (EmployeeID).

-------------------------------------------------------------------------------------------------------------------------------
--11) Repeat the above operation of Training database tables as well
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

USE Training
go

SELECT DB_NAME()
go

sp_help
go

sp_help Student_Marks
go



