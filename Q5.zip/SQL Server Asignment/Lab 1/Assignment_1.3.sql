-------------------------------------------------------------------------------------------------------------------------------
--                                                 Lab 1 Assignment 
--                    Assignment 1.3 :-SQL Languages � DDL- Creating Tables, Alias Data Type and Constraints
-------------------------------------------------------------------------------------------------------------------------------

-------------------------------------------------------------------------------------------------------------------------------
--1) Create a Table called Customer_<empid> with the following Columns
--	Customerid Int Unique NOT NULL
--	CustomerName varchar(20) Not Null
--	Address1 varchar(30)
--	Address2 varchar(30)
--	Contact Number varchar(12) Not Null
--	Postal Code Varchar(10)
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE TABLE Customer_121880
(   Customerid		Int             Unique NOT NULL,
	CustomerName	varchar(20)		Not Null,
	Address1		varchar(30),
	Address2		varchar(30),
	ContactNumber	varchar(12)		Not Null,
	PostalCode		Varchar(10)
);

-------------------------------------------------------------------------------------------------------------------------------
--2)  Create a table called Employees_<empid>
--	CREATE TABLE Employees
--	(
--	EmployeeId INT NOT NULL PRIMARY KEY,
--	Name NVARCHAR(255) NULL
--	);
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE TABLE Employees_121880
(
	EmployeeId	INT				NOT NULL PRIMARY KEY,
	Name		NVARCHAR(255)	NULL
);

-------------------------------------------------------------------------------------------------------------------------------
--3) Create a table called Contractors_<empid>
--CREATE TABLE Contractors
--(
--	ContractorId INT NOT NULL PRIMARY KEY,
--	Name NVARCHAR(255) NULL
--);
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE TABLE Contractors_121880
(
	ContractorId	INT				NOT NULL PRIMARY KEY,
	Name			NVARCHAR(255)	NULL
);

-------------------------------------------------------------------------------------------------------------------------------
--4) Create a table called TestRethrow_<empid>
--USE Training;
--CREATE TABLE dbo.TestRethrow
--(
--	ID INT PRIMARY KEY
--);
--In Object Explorer, go to Databases | Training| Tables and you should see
--Customers, Employees, Contractors and TestRethrow tables created
-------------------------------------------------------------------------------------------------------------------------------
-- Solution :-

CREATE TABLE dbo.TestRethrow_121880
(
	ID	INT PRIMARY KEY
);

-------------------------------------------------------------------------------------------------------------------------------		
--4.1) Create a user defined data type called Region, which would store a character string
--of size 15.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE TYPE Region_121880
FROM char(15) NOT NULL;

-------------------------------------------------------------------------------------------------------------------------------
--4.2) Create a Default which would store the value �NA� (North America�) ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE DEFAULT Location
AS 'NA'
GO

EXEC sp_bindefault Location,
Region_121880;

-------------------------------------------------------------------------------------------------------------------------------
--4.3) Bind the default to the Alias Data Type of Q1 i.e. region ?
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

EXEC sp_bindefault Location,
Region_121880;

-------------------------------------------------------------------------------------------------------------------------------
--4.4) Modify the table Customers to add the a column called Customer_Region which
--would be of data type:
--Region
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

ALTER TABLE Customer_121880
ADD Customer_Region Region NOT NULL

-------------------------------------------------------------------------------------------------------------------------------
--4.5) Add the column to the Customer Table.
--Gender char (1)
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

ALTER TABLE Customer_121880
ADD Gender char(1) NOT NULL


-------------------------------------------------------------------------------------------------------------------------------
--4.6) Using alter table statement add a constraint to the Gender column such that it would
--not accept any other values except �M�,�F� and �T�.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

ALTER TABLE Customer_121880
ADD CONSTRAINT check_gender_121880 CHECK (Gender='M' OR Gender='F' OR Gender='T')

-------------------------------------------------------------------------------------------------------------------------------
--4.7) Create the Table Orders with the following Columns:
--OrdersID Int NOT NULL IDENTITY with starting values 1000
--Customerld Int Not Null
--OrdersDate Datetime
--Order_State char(1) can be only �P� or �C�
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE TABLE Order_121880
( OrdersID		Int		NOT NULL IDENTITY(1000,1),
  CustomerId    Int     NOT NULL,
  OrderDate     Datetime,
  Order_State   char(1) CHECK (Order_State IN ('P','C'))
);

-------------------------------------------------------------------------------------------------------------------------------
--4.8) Add referential integrity constraint for Orders & Customer tables through Customerld
--with the name fk_CustOrders.
--Using sp_help check if the constraints have been added properly.
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

ALTER TABLE Order_121880
ADD CONSTRAINT fk_CustOrders_121880
FOREIGN KEY (CustomerId)
REFERENCES Customer_121880(CustomerId)

-------------------------------------------------------------------------------------------------------------------------------
--4.9) Creating and using Sequence Numbers

--4.9.1) Copy and paste the following code segment in query editor.
--SQL
--USE Training;
--CREATE SEQUENCE IdSequence AS INT
--START WITH 10000
--INCREMENT BY 1;
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

CREATE SEQUENCE IdSequence_121880 AS INT
START WITH 10000
INCREMENT BY 1;

-------------------------------------------------------------------------------------------------------------------------------
--4.9.2) Copy and paste the following code segment in query editor.
--SQL
--USE Training;
--INSERT INTO Employees (EmployeeId, Name)
--VALUES (NEXT VALUE FOR IdSequence, 'Shashank');
--INSERT INTO Contractors (ContractorId, Name)
--VALUES (NEXT VALUE FOR IdSequence, 'Aditya');
--SELECT * FROM Employees;
--SELECT * FROM Contractors;
-------------------------------------------------------------------------------------------------------------------------------
--Solution :-

INSERT INTO Employees_121880 (EmployeeId, Name)
VALUES (NEXT VALUE FOR IdSequence, 'Shashank');

INSERT INTO Contractors_121880 (ContractorId, Name)
VALUES (NEXT VALUE FOR IdSequence, 'Aditya');

SELECT * FROM Employees_121880;

SELECT * FROM Contractors_121880;